-- DeathMark v1.54 (Bronzebeard)
-- PvP Healer Detection Addon for Project Ascension 3.3.5a
-- Fixes in 1.54:
--   1. Sound default OFF; per-healer 5s sound cooldown to stop spam
--   2. NPC filter: combat log now requires COMBATLOG_OBJECT_TYPE_PLAYER (kills Environment/mob detections)
--   3. Nameplate markers: EnableMouse(false) so clicks pass through; replaced filled box with bordered rank badge
--   4. Marker pulses red border (not green fill) when healer is actively casting

local VERSION = "1.55"
local ADDON_NAME = "DeathMark_Bronzebeard"

-- ============================================================
-- CONSTANTS
-- ============================================================
local HUD_WIDTH    = 240
local ROW_HEIGHT   = 22
local TITLE_HEIGHT = 20

local HEALER_CLASSES = {
    PRIEST=true, DRUID=true, SHAMAN=true, PALADIN=true,
    Priest=true, Druid=true, Shaman=true, Paladin=true,
}

local CLASS_COLORS = {
    PRIEST  = {r=1,    g=1,    b=1   },
    DRUID   = {r=1,    g=0.49, b=0.04},
    SHAMAN  = {r=0,    g=0.44, b=0.87},
    PALADIN = {r=0.96, g=0.55, b=0.73},
    HUNTER  = {r=0.67, g=0.83, b=0.45},
    MAGE    = {r=0.41, g=0.8,  b=0.94},
    WARRIOR = {r=0.78, g=0.61, b=0.43},
    ROGUE   = {r=1,    g=0.96, b=0.41},
    WARLOCK = {r=0.58, g=0.51, b=0.79},
    DEATHKNIGHT = {r=0.77, g=0.12, b=0.23},
}

local SORT_MODES = {"closest","furthest","health","recent"}

-- ============================================================
-- SAVED VARIABLES DEFAULTS
-- ============================================================
local DB_DEFAULTS = {
    enabled       = true,
    sound         = false,   -- off by default, enable in options
    chatAlerts    = true,
    nameplateColor= true,
    sortMode      = "closest",
    hudVisible    = true,
    hudLocked     = false,
    hudMaxRows    = 8,       -- max rows shown before HUD clips; drag resize grip to change
    hudX          = nil,
    hudY          = nil,
    minimapAngle  = 225,
    firstLoad     = true,
    debug         = false,
    addonVersion  = VERSION,
}

-- ============================================================
-- RUNTIME STATE
-- ============================================================
local healers      = {}   -- [name] = {name, class, level, unit, hp, hpMax, mana, manaMax, range, lastHeal, firstSeen, isHealing}
local friendlySet  = {}   -- [name] = true
-- FIX 2: combat log heal counter for unknown-class players
local healCastCount = {}  -- [name] = count of heals seen before confirmed class
local UNKNOWN_HEAL_THRESHOLD = 2  -- flag after this many heals

local inBG         = false
local scanRetryTimer = 0
local scanRetryCount = 0
local MAX_SCAN_RETRIES = 3
local SCAN_RETRY_DELAYS = {3, 8, 15}  -- seconds after BG entry

local hudRows      = {}
local alertFrame   = nil
local detectedFrame= nil
local nameplateMarkers = {}

-- ============================================================
-- UTILITY
-- ============================================================
local function StripRealm(n)
    if not n then return "" end
    return n:match("^([^%-]+)") or n
end

local function Debug(msg)
    if DeathMarkDB and DeathMarkDB.debug then
        print("|cffaaaaff[DM-DEBUG]|r " .. tostring(msg))
    end
end

local function GetClassColor(class)
    if not class then return {r=0.8,g=0.8,b=0.8} end
    local key = string.upper(class)
    return CLASS_COLORS[key] or {r=0.8,g=0.8,b=0.8}
end

local function IsInBG()
    local _, instanceType = IsInInstance()
    return instanceType == "pvp"
end

-- ============================================================
-- RANGE ESTIMATION
-- ============================================================
local function EstimateRange(unit)
    if not unit or not UnitExists(unit) then return 999 end
    if CheckInteractDistance(unit, 4) then return 5   end
    if CheckInteractDistance(unit, 3) then return 9   end
    if CheckInteractDistance(unit, 2) then return 13  end
    if CheckInteractDistance(unit, 1) then return 28  end
    return 40
end

-- ============================================================
-- FIND CURRENT UNIT (nameplate token refresh)
-- ============================================================
local function FindCurrentUnit(d)
    local stripped = StripRealm(d.name)

    -- Check target
    if UnitExists("target") then
        local tname = StripRealm(UnitName("target"))
        if tname == stripped then
            d.unit = "target"
            local lvl = UnitLevel("target")
            if lvl and lvl > 0 then d.level = lvl end
            local cls = UnitClass("target")
            if cls then d.class = cls end
            return "target"
        end
    end

    -- Check focus
    if UnitExists("focus") then
        local fname = StripRealm(UnitName("focus"))
        if fname == stripped then
            d.unit = "focus"
            return "focus"
        end
    end

    -- Check stored unit
    if d.unit and UnitExists(d.unit) then
        local uname = StripRealm(UnitName(d.unit))
        if uname == stripped then
            return d.unit
        end
    end

    -- FIX 3: Try multiple nameplate name paths
    for i = 1, 40 do
        local token = "nameplate"..i
        if UnitExists(token) then
            local npname = StripRealm(UnitName(token))
            if npname == stripped then
                d.unit = token
                return token
            end
        end
    end

    d.unit = nil
    return nil
end

-- ============================================================
-- FIX 3: GET NAMEPLATE NAME — tries multiple frame paths
-- ============================================================
local function GetNameplateName(npFrame)
    if not npFrame then return nil end

    -- Path 1: direct .name child (most common)
    if npFrame.name and npFrame.name.GetText then
        local t = npFrame.name:GetText()
        if t and t ~= "" then return t end
    end

    -- Path 2: UnitFrame.name (Ascension nested layout)
    if npFrame.UnitFrame and npFrame.UnitFrame.name then
        local t = npFrame.UnitFrame.name:GetText()
        if t and t ~= "" then return t end
    end

    -- Path 3: iterate children looking for a FontString named "name"
    for i = 1, npFrame:GetNumChildren() do
        local child = select(i, npFrame:GetChildren())
        if child and child.GetName and child:GetName() and
           string.find(string.lower(child:GetName()), "name") then
            if child.GetText then
                local t = child:GetText()
                if t and t ~= "" then return t end
            end
        end
    end

    -- Path 4: iterate all regions (FontStrings) in the frame
    for i = 1, npFrame:GetNumRegions() do
        local region = select(i, npFrame:GetRegions())
        if region and region.GetText then
            local t = region:GetText()
            if t and t ~= "" and not tonumber(t) then
                return t
            end
        end
    end

    return nil
end

-- ============================================================
-- ALERT BANNERS
-- ============================================================
function ShowAlert(name)
    if not alertFrame then return end
    alertFrame.text:SetText("|cffff2222⚕ "..name.." IS HEALING!|r")
    alertFrame:Show()
    alertFrame.fadeTimer = 3
    if DeathMarkDB.sound then
        PlaySoundFile("Sound\\Spells\\PVPFlagTaken.wav")
    end
end

function ShowDetected(name)
    if not detectedFrame then return end
    detectedFrame.text:SetText("|cffffff00☠ "..name.." DETECTED|r")
    detectedFrame:Show()
    detectedFrame.fadeTimer = 3
end

-- ============================================================
-- MARK HEALER
-- ============================================================
local function AddHealer(name, class, level, unit)
    local stripped = StripRealm(name)
    if healers[stripped] then return end
    if friendlySet[stripped] then return end

    healers[stripped] = {
        name      = stripped,
        class     = class or "UNKNOWN",
        level     = level or 0,
        unit      = unit,
        hp        = 100,
        hpMax     = 100,
        mana      = 100,
        manaMax   = 100,
        range     = 999,
        lastHeal  = 0,
        firstSeen = GetTime(),
        isHealing = false,
    }
    Debug("Added healer: "..stripped.." ("..tostring(class)..")")
    ShowDetected(stripped)
    if DeathMarkDB.chatAlerts then
        print("|cffff4444[DeathMark]|r Healer detected: |cffffff00"..stripped.."|r ("..tostring(class)..")")
    end
end

local function MarkHealing(name)
    local stripped = StripRealm(name)
    local d = healers[stripped]
    if not d then return end
    d.isHealing = true
    d.lastHeal  = GetTime()
    -- Sound cooldown: only play once every 5s per healer to avoid spam
    local now = GetTime()
    if not d.lastSound or (now - d.lastSound) >= 5 then
        d.lastSound = now
        ShowAlert(stripped)
    else
        -- Still show the visual banner, just no sound
        if alertFrame then
            alertFrame.text:SetText("|cffff2222⚕ "..stripped.." IS HEALING!|r")
            alertFrame:Show()
            alertFrame.fadeTimer = 3
        end
    end
end

local bgInitialScanDone = false  -- true after first successful population scan

-- ============================================================
-- SCOREBOARD SCAN
-- ============================================================
-- initialScan=true: populates new healers (used on BG entry retries)
-- initialScan=false: only refreshes friendlySet, does NOT add new healers (used on UPDATE_BATTLEFIELD_SCORE)
local function ScanBattlefieldRoster(initialScan)
    if not IsInBG() then return end

    friendlySet = {}

    -- Build friendly set from raid/party
    for i = 1, GetNumGroupMembers() do
        local unit = (IsInRaid() and "raid"..i or "party"..i)
        if UnitExists(unit) then
            local n = StripRealm(UnitName(unit) or "")
            if n ~= "" then friendlySet[n] = true end
        end
    end
    friendlySet[StripRealm(UnitName("player") or "")] = true

    local count = GetNumBattlefieldScores()
    Debug("ScanBattlefieldRoster(initial="..tostring(initialScan).."): "..count.." scores")

    if count == 0 then
        Debug("Scoreboard empty — will retry")
        return false
    end

    if initialScan then
        for i = 1, count do
            local data = {GetBattlefieldScore(i)}
            local name       = StripRealm(data[1] or "")
            local classToken = data[9] or ""

            if name ~= "" and not friendlySet[name] then
                if HEALER_CLASSES[classToken] then
                    local cls = string.upper(classToken)
                    AddHealer(name, cls, 0, nil)
                end
            end
        end
        bgInitialScanDone = true
    end
    -- Non-initial scans only update friendlySet (already done above)
    return true
end

-- ============================================================
-- FIX 2: COMBAT LOG FALLBACK — flag unknown healers after threshold
-- ============================================================
local function HandleCombatLogHeal(sourceName, spellName)
    if not inBG then return end
    local stripped = StripRealm(sourceName)
    if not stripped or stripped == "" then return end
    if friendlySet[stripped] then return end

    -- Already tracked — just mark healing
    if healers[stripped] then
        MarkHealing(stripped)
        return
    end

    -- Unknown class — increment counter
    healCastCount[stripped] = (healCastCount[stripped] or 0) + 1
    Debug("Unknown class heal from: "..stripped.." (count="..healCastCount[stripped]..")")

    if healCastCount[stripped] >= UNKNOWN_HEAL_THRESHOLD then
        Debug("Fallback flagging healer from combat log: "..stripped)
        AddHealer(stripped, "UNKNOWN", 0, nil)
        MarkHealing(stripped)
        healCastCount[stripped] = nil
    end
end

-- ============================================================
-- HUD FRAME
-- ============================================================
local DeathMarkHUD

local function CreateHUD()
    DeathMarkHUD = CreateFrame("Frame", "DeathMarkHUD", UIParent)
    DeathMarkHUD:SetFrameStrata("HIGH")
    DeathMarkHUD:SetWidth(HUD_WIDTH)
    DeathMarkHUD:SetHeight(TITLE_HEIGHT)
    DeathMarkHUD:SetPoint("RIGHT", UIParent, "RIGHT", -20, 0)
    DeathMarkHUD:SetMovable(true)
    -- Drag is handled by the title bar button below, not the parent frame,
    -- because the title bar Button would eat mouse events from the parent.

    -- Background
    local bg = DeathMarkHUD:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(0, 0, 0, 0.7)
    DeathMarkHUD.bg = bg

    -- Title bar (Button so it gets mouse events for right-click + tooltip)
    local titleBar = CreateFrame("Button", nil, DeathMarkHUD)
    titleBar:SetHeight(TITLE_HEIGHT)
    titleBar:SetPoint("TOPLEFT")
    titleBar:SetPoint("TOPRIGHT")
    titleBar:RegisterForClicks("RightButtonUp")
    titleBar:RegisterForDrag("LeftButton")
    titleBar:SetMovable(true)
    titleBar:SetScript("OnDragStart", function()
        if not DeathMarkDB.hudLocked then
            DeathMarkHUD:StartMoving()
        end
    end)
    titleBar:SetScript("OnDragStop", function()
        DeathMarkHUD:StopMovingOrSizing()
        local x, y = DeathMarkHUD:GetCenter()
        local ux, uy = UIParent:GetCenter()
        DeathMarkDB.hudX = x - ux
        DeathMarkDB.hudY = y - uy
    end)
    local titleBg = titleBar:CreateTexture(nil, "BACKGROUND")
    titleBg:SetAllPoints()
    titleBg:SetTexture(0.6, 0, 0, 0.9)

    local titleText = titleBar:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    titleText:SetPoint("LEFT", 6, 0)
    titleText:SetText("|cffff4444☩ DEATHMARK|r")
    DeathMarkHUD.titleText = titleText

    -- Title bar tooltip
    titleBar:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_BOTTOM")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("|cffff4444☩ DeathMark|r v"..VERSION)
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("|cffffd700Right-click|r for options", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("|cffffd700Left-drag|r to move (when unlocked)", 0.8, 0.8, 0.8)
        GameTooltip:AddLine(" ")
        local count = 0
        for _ in pairs(healers) do count = count + 1 end
        GameTooltip:AddLine("Healers tracked: |cffffff00"..count.."|r", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("Sort: |cffffff00"..(DeathMarkDB.sortMode or "closest").."|r", 0.8, 0.8, 0.8)
        GameTooltip:AddLine("HUD: |cffffff00"..(DeathMarkDB.hudLocked and "Locked" or "Unlocked").."|r", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    titleBar:SetScript("OnLeave", function() GameTooltip:Hide() end)

    -- Right-click context menu
    local titleMenu = CreateFrame("Frame", "DeathMarkTitleMenu", UIParent, "UIDropDownMenuTemplate")
    titleBar:SetScript("OnClick", function(self, btn)
        if btn ~= "RightButton" then return end
        GameTooltip:Hide()
        local healerCount = 0
        for _ in pairs(healers) do healerCount = healerCount + 1 end

        local menuList = {
            { text = "☩ DeathMark v"..VERSION, isTitle = true, notCheckable = true },
            { text = " ", isTitle = true, notCheckable = true },
            {
                text = "Scan Scoreboard",
                notCheckable = true,
                func = function()
                    healers = {}
                    healCastCount = {}
                    ScanBattlefieldRoster()
                    print("|cffff4444[DeathMark]|r Manual scan triggered.")
                end,
            },
            {
                text = "Clear Healer List  ("..healerCount..")",
                notCheckable = true,
                func = function()
                    healers = {}
                    healCastCount = {}
                    print("|cffff4444[DeathMark]|r Healer list cleared.")
                end,
            },
            { text = " ", isTitle = true, notCheckable = true },
            {
                text = "Sort: Closest",
                notCheckable = true,
                func = function() DeathMarkDB.sortMode = "closest" end,
            },
            {
                text = "Sort: Furthest",
                notCheckable = true,
                func = function() DeathMarkDB.sortMode = "furthest" end,
            },
            {
                text = "Sort: Low HP",
                notCheckable = true,
                func = function() DeathMarkDB.sortMode = "health" end,
            },
            {
                text = "Sort: Recent",
                notCheckable = true,
                func = function() DeathMarkDB.sortMode = "recent" end,
            },
            { text = " ", isTitle = true, notCheckable = true },
            {
                text = DeathMarkDB.hudLocked and "Unlock HUD" or "Lock HUD",
                notCheckable = true,
                func = function()
                    DeathMarkDB.hudLocked = not DeathMarkDB.hudLocked
                    if DeathMarkHUD.lockBtn then
                        DeathMarkHUD.lockBtn:SetText(DeathMarkDB.hudLocked and "|cffff4444[L]|r" or "|cff44ff44[U]|r")
                    end
                end,
            },
            {
                text = "Reset HUD Position",
                notCheckable = true,
                func = function()
                    DeathMarkDB.hudX = nil
                    DeathMarkDB.hudY = nil
                    DeathMarkHUD:ClearAllPoints()
                    DeathMarkHUD:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
                end,
            },
            { text = " ", isTitle = true, notCheckable = true },
            {
                text = "Options Panel",
                notCheckable = true,
                func = function()
                    if DeathMarkOptions then DeathMarkOptions:Show() end
                end,
            },
            {
                text = "Hide HUD",
                notCheckable = true,
                func = function()
                    DeathMarkDB.hudVisible = false
                    print("|cffff4444[DeathMark]|r HUD hidden. Use /dm hud to restore.")
                end,
            },
        }
        EasyMenu(menuList, titleMenu, "cursor", 0, 0, "MENU")
    end)

    -- Sort button
    local sortBtn = CreateFrame("Button", nil, titleBar)
    sortBtn:SetSize(54, 14)
    sortBtn:SetPoint("RIGHT", scanBtn, "LEFT", -2, 0)
    sortBtn:SetNormalFontObject("GameFontNormalSmall")
    DeathMarkHUD.sortBtn = sortBtn
    sortBtn:SetScript("OnClick", function()
        local cur = DeathMarkDB.sortMode
        local idx = 1
        for i, v in ipairs(SORT_MODES) do if v == cur then idx = i break end end
        idx = (idx % #SORT_MODES) + 1
        DeathMarkDB.sortMode = SORT_MODES[idx]
        sortBtn:SetText("|cffffff00["..SORT_MODES[idx].."]|r")
    end)
    sortBtn:SetText("|cffffff00[closest]|r")

    -- Lock button
    local lockBtn = CreateFrame("Button", nil, titleBar)
    lockBtn:SetSize(20, 14)
    lockBtn:SetPoint("RIGHT", titleBar, "RIGHT", -4, 0)
    lockBtn:SetNormalFontObject("GameFontNormalSmall")
    DeathMarkHUD.lockBtn = lockBtn
    lockBtn:SetScript("OnClick", function()
        DeathMarkDB.hudLocked = not DeathMarkDB.hudLocked
        lockBtn:SetText(DeathMarkDB.hudLocked and "|cffff4444[L]|r" or "|cff44ff44[U]|r")
    end)
    lockBtn:SetText("|cff44ff44[U]|r")

    -- No healers label
    local noHealers = DeathMarkHUD:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    noHealers:SetPoint("TOPLEFT", 6, -(TITLE_HEIGHT + 4))
    noHealers:SetText("|cff888888No healers detected|r")
    DeathMarkHUD.noHealers = noHealers

    -- Resize grip — bottom-right corner, drag up/down to change max visible rows
    local grip = CreateFrame("Frame", nil, DeathMarkHUD)
    grip:SetSize(HUD_WIDTH, 6)
    grip:SetPoint("BOTTOMLEFT", DeathMarkHUD, "BOTTOMLEFT", 0, 0)
    grip:SetPoint("BOTTOMRIGHT", DeathMarkHUD, "BOTTOMRIGHT", 0, 0)
    grip:EnableMouse(true)
    grip:RegisterForDrag("LeftButton")
    grip:SetScript("OnDragStart", function(self) self:StartMoving() end)

    local gripTex = grip:CreateTexture(nil, "OVERLAY")
    gripTex:SetAllPoints()
    gripTex:SetTexture(0.5, 0.5, 0.5, 0.4)

    local gripLabel = grip:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    gripLabel:SetPoint("CENTER")
    gripLabel:SetText("|cff888888⠿|r")

    -- Track drag for resizing
    local dragStartY = nil
    local dragStartRows = nil
    grip:SetScript("OnMouseDown", function(self, btn)
        if btn == "LeftButton" and not DeathMarkDB.hudLocked then
            dragStartY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
            dragStartRows = DeathMarkDB.hudMaxRows or 8
        end
    end)
    grip:SetScript("OnUpdate", function(self)
        if dragStartY and IsMouseButtonDown("LeftButton") and not DeathMarkDB.hudLocked then
            local curY = select(2, GetCursorPosition()) / UIParent:GetEffectiveScale()
            local delta = dragStartY - curY  -- dragging down = more rows
            local newRows = math.max(2, math.min(20, dragStartRows + math.floor(delta / ROW_HEIGHT + 0.5)))
            if newRows ~= DeathMarkDB.hudMaxRows then
                DeathMarkDB.hudMaxRows = newRows
            end
        elseif not IsMouseButtonDown("LeftButton") then
            dragStartY = nil
        end
    end)
    grip:SetScript("OnEnter", function()
        GameTooltip:SetOwner(grip, "ANCHOR_TOP")
        GameTooltip:ClearLines()
        GameTooltip:AddLine("Drag to resize", 1, 1, 0)
        GameTooltip:AddLine("Current: "..(DeathMarkDB.hudMaxRows or 8).." rows", 0.8, 0.8, 0.8)
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", function() GameTooltip:Hide() end)
    DeathMarkHUD.grip = grip

    DeathMarkHUD:Hide()
end

-- ============================================================
-- HUD ROWS
-- ============================================================
local function GetOrCreateRow(idx)
    if hudRows[idx] then return hudRows[idx] end

    local row = CreateFrame("Button", nil, DeathMarkHUD, "SecureActionButtonTemplate")
    row:SetSize(HUD_WIDTH, ROW_HEIGHT)
    row:SetPoint("TOPLEFT", 0, -(TITLE_HEIGHT + (idx-1)*ROW_HEIGHT))
    row:SetAttribute("type", "macro")
    row:RegisterForClicks("LeftButtonUp")

    -- Accent bar
    local accent = row:CreateTexture(nil, "BACKGROUND")
    accent:SetSize(3, ROW_HEIGHT)
    accent:SetPoint("TOPLEFT")
    row.accent = accent

    -- Row background
    local rowbg = row:CreateTexture(nil, "BACKGROUND")
    rowbg:SetPoint("TOPLEFT", 3, 0)
    rowbg:SetPoint("BOTTOMRIGHT")
    rowbg:SetTexture(0.1, 0.1, 0.1, 0.5)
    row.rowbg = rowbg

    -- Arrow
    local arrow = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    arrow:SetPoint("LEFT", 6, 2)
    arrow:SetWidth(14)
    row.arrow = arrow

    -- Name
    local nameStr = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    nameStr:SetPoint("TOPLEFT", 22, -3)
    nameStr:SetWidth(110)
    nameStr:SetJustifyH("LEFT")
    row.nameStr = nameStr

    -- Class label
    local classStr = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    classStr:SetPoint("TOPLEFT", 22, -13)
    classStr:SetWidth(80)
    classStr:SetJustifyH("LEFT")
    row.classStr = classStr

    -- HP bar background
    local hpBg = row:CreateTexture(nil, "ARTWORK")
    hpBg:SetPoint("TOPLEFT", 140, -4)
    hpBg:SetSize(88, 8)
    hpBg:SetTexture(0.2, 0.2, 0.2, 0.8)
    row.hpBg = hpBg

    -- HP bar fill
    local hpBar = row:CreateTexture(nil, "ARTWORK")
    hpBar:SetPoint("TOPLEFT", 140, -4)
    hpBar:SetHeight(8)
    row.hpBar = hpBar

    -- Mana bar
    local manaBar = row:CreateTexture(nil, "ARTWORK")
    manaBar:SetPoint("BOTTOMLEFT", 140, 2)
    manaBar:SetHeight(3)
    manaBar:SetTexture(0.1, 0.4, 0.9, 0.9)
    row.manaBar = manaBar

    -- Range/HP text
    local rangeStr = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    rangeStr:SetPoint("TOPRIGHT", -4, -3)
    rangeStr:SetWidth(50)
    rangeStr:SetJustifyH("RIGHT")
    row.rangeStr = rangeStr

    -- Heal flash dot
    local healDot = row:CreateTexture(nil, "OVERLAY")
    healDot:SetSize(8, 8)
    healDot:SetPoint("BOTTOMRIGHT", -4, 3)
    healDot:SetTexture(0, 1, 0.3, 0)
    row.healDot = healDot

    -- Tooltip
    row:SetScript("OnEnter", function(self)
        if self.data then
            local d = self.data
            GameTooltip:SetOwner(self, "ANCHOR_LEFT")
            GameTooltip:ClearLines()
            GameTooltip:AddLine(d.name, 1, 1, 0)
            GameTooltip:AddLine("Level: "..(d.level > 0 and d.level or "??"), 0.8, 0.8, 0.8)
            GameTooltip:AddLine("Class: "..(d.class or "Unknown"), 0.8, 0.8, 0.8)
            local rng = (d.range < 999) and ("~"..d.range.."y") or "?y"
            GameTooltip:AddLine("Distance: "..rng, 0.8, 0.8, 0.8)
            local hpPct = (d.hpMax > 0) and math.floor(d.hp/d.hpMax*100) or 0
            GameTooltip:AddLine("Life: "..hpPct.."%", 0.8, 0.8, 0.8)
            local manaPct = (d.manaMax > 0) and math.floor(d.mana/d.manaMax*100) or 0
            GameTooltip:AddLine("Mana: "..manaPct.."%", 0.4, 0.6, 1)
            if d.isHealing then
                GameTooltip:AddLine("⚕ ACTIVELY HEALING", 1, 0.2, 0.2)
            end
            GameTooltip:Show()
        end
    end)
    row:SetScript("OnLeave", function() GameTooltip:Hide() end)

    hudRows[idx] = row
    return row
end

-- ============================================================
-- SORT HEALERS
-- ============================================================
local function SortHealers()
    local list = {}
    for _, d in pairs(healers) do
        table.insert(list, d)
    end

    local mode = DeathMarkDB.sortMode or "closest"
    local now = GetTime()

    table.sort(list, function(a, b)
        if mode == "closest" then
            return (a.range or 999) < (b.range or 999)
        elseif mode == "furthest" then
            return (a.range or 999) > (b.range or 999)
        elseif mode == "health" then
            local apct = (a.hpMax > 0) and (a.hp/a.hpMax) or 1
            local bpct = (b.hpMax > 0) and (b.hp/b.hpMax) or 1
            return apct < bpct
        elseif mode == "recent" then
            return (a.lastHeal or 0) > (b.lastHeal or 0)
        end
        return false
    end)
    return list
end

-- ============================================================
-- UPDATE HUD
-- ============================================================
local function UpdateHUD()
    if not DeathMarkHUD then return end
    if not DeathMarkDB or not DeathMarkDB.enabled then
        DeathMarkHUD:Hide()
        return
    end
    if not DeathMarkDB.hudVisible then
        DeathMarkHUD:Hide()
        return
    end

    DeathMarkHUD:Show()

    local list = {}

    -- Preview mode outside BG
    if not IsInBG() then
        list = {
            {name="Longshaft",    class="HUNTER",  level=60, hp=672, hpMax=672,  mana=805, manaMax=805,  range=0,  lastHeal=0, isHealing=false},
            {name="EnemyHealer",  class="PRIEST",  level=60, hp=450, hpMax=900,  mana=600, manaMax=1200, range=18, lastHeal=GetTime()-1, isHealing=true},
            {name="AnotherHlr",   class="SHAMAN",  level=58, hp=800, hpMax=800,  mana=200, manaMax=1000, range=35, lastHeal=0, isHealing=false},
        }
    else
        list = SortHealers()
    end

    -- Update sort button label
    if DeathMarkHUD.sortBtn then
        DeathMarkHUD.sortBtn:SetText("|cffffff00["..(DeathMarkDB.sortMode or "closest").."]|r")
    end

    -- Update lock button
    if DeathMarkHUD.lockBtn then
        DeathMarkHUD.lockBtn:SetText(DeathMarkDB.hudLocked and "|cffff4444[L]|r" or "|cff44ff44[U]|r")
    end

    local now = GetTime()

    if #list == 0 then
        DeathMarkHUD.noHealers:Show()
        DeathMarkHUD:SetHeight(TITLE_HEIGHT + 20)
        for i, row in ipairs(hudRows) do row:Hide() end
        return
    end

    DeathMarkHUD.noHealers:Hide()

    local maxRows = DeathMarkDB.hudMaxRows or 8
    local overflow = math.max(0, #list - maxRows)
    local visibleList = {}
    for i = 1, math.min(#list, maxRows) do
        visibleList[i] = list[i]
    end

    for i, d in ipairs(visibleList) do

        local cc = GetClassColor(d.class)

        -- Accent bar
        row.accent:SetTexture(cc.r, cc.g, cc.b, 1)

        -- Arrow direction (only available when unit is target)
        local unit = FindCurrentUnit(d)
        local arrowChar = "|cff888888-|r"
        if unit and UnitExists(unit) then
            -- UnitPosition doesn't work on enemies; show indicator that unit is visible
            arrowChar = "|cffffcc00◈|r"
        end
        row.arrow:SetText(arrowChar)

        -- Level prefix + name
        local levelPfx = (d.level and d.level > 0) and ("|cff888888["..d.level.."]|r ") or ""
        row.nameStr:SetText(levelPfx.."|cff"..string.format("%02x%02x%02x", cc.r*255, cc.g*255, cc.b*255)..d.name.."|r")

        -- Class label
        local clsDisplay = d.class or "Unknown"
        if clsDisplay == "UNKNOWN" then clsDisplay = "?" end
        row.classStr:SetText("|cff666666"..clsDisplay.."|r")

        -- HP bar
        local hpPct = (d.hpMax > 0) and (d.hp/d.hpMax) or 0
        row.hpBar:SetWidth(math.max(1, math.floor(88 * hpPct)))
        if hpPct > 0.6 then
            row.hpBar:SetTexture(0.1, 0.8, 0.2, 1)
        elseif hpPct > 0.3 then
            row.hpBar:SetTexture(0.9, 0.7, 0.1, 1)
        else
            row.hpBar:SetTexture(0.9, 0.1, 0.1, 1)
        end

        -- Mana bar
        local manaPct = (d.manaMax > 0) and (d.mana/d.manaMax) or 0
        row.manaBar:SetWidth(math.max(1, math.floor(88 * manaPct)))

        -- Range + HP%
        local rngStr = (d.range < 999) and ("~"..d.range.."y") or "?y"
        local hpPctStr = math.floor(hpPct*100).."%"
        if hpPct < 0.3 then
            row.rangeStr:SetText("|cffff4444"..hpPctStr.."|r\n"..rngStr)
        elseif hpPct < 0.6 then
            row.rangeStr:SetText("|cffffff44"..hpPctStr.."|r\n"..rngStr)
        else
            row.rangeStr:SetText("|cff44ff44"..hpPctStr.."|r\n"..rngStr)
        end

        -- Heal flash dot
        if d.isHealing and (now - (d.lastHeal or 0)) < 3 then
            row.healDot:SetTexture(0, 1, 0.3, 0.9)
        else
            d.isHealing = false
            row.healDot:SetTexture(0, 0, 0, 0)
        end

        -- Click to target macro
        row:SetAttribute("macrotext", "/target "..d.name)

        row:Show()
    end

    -- Hide unused rows
    for i = #visibleList+1, #hudRows do
        hudRows[i]:Hide()
    end

    -- Overflow label
    if not DeathMarkHUD.overflowLabel then
        DeathMarkHUD.overflowLabel = DeathMarkHUD:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    end
    if overflow > 0 then
        DeathMarkHUD.overflowLabel:SetPoint("TOPLEFT", 6, -(TITLE_HEIGHT + #visibleList * ROW_HEIGHT + 2))
        DeathMarkHUD.overflowLabel:SetText("|cff888888+ "..overflow.." more — drag ⠿ to resize|r")
        DeathMarkHUD.overflowLabel:Show()
    else
        DeathMarkHUD.overflowLabel:Hide()
    end

    local extraH = (overflow > 0) and 14 or 0
    -- +6 for resize grip at bottom
    DeathMarkHUD:SetHeight(TITLE_HEIGHT + (#visibleList * ROW_HEIGHT) + extraH + 6)
end

-- ============================================================
-- NAMEPLATE MARKERS (FIX 3 integrated)
-- ============================================================
local function GetOrCreateMarker(name)
    if nameplateMarkers[name] then return nameplateMarkers[name] end
    local marker = CreateFrame("Frame", nil, WorldFrame)
    marker:SetSize(14, 14)
    marker:SetFrameStrata("TOOLTIP")
    marker:EnableMouse(false)  -- clicks pass through to nameplate/unit underneath

    -- Thin colored border, transparent fill
    local border = marker:CreateTexture(nil, "BACKGROUND")
    border:SetAllPoints()
    border:SetTexture(0, 0, 0, 0)  -- invisible fill; border drawn via backdrop below
    marker.border = border

    -- Use backdrop for a clean bordered box look
    if marker.SetBackdrop then
        marker:SetBackdrop({
            edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
            edgeSize = 8,
            insets = {left=2, right=2, top=2, bottom=2},
        })
    end

    -- Rank number centered
    local lbl = marker:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    lbl:SetPoint("CENTER", 0, 0)
    lbl:SetFont("Fonts\\FRIZQT__.TTF", 9, "OUTLINE")
    marker.lbl = lbl

    marker:Hide()
    nameplateMarkers[name] = marker
    return marker
end

local function UpdateNameplateMarkers()
    -- Hide all first
    for _, m in pairs(nameplateMarkers) do m:Hide() end

    if not IsInBG() then return end

    local sortedList = SortHealers()
    for rank, d in ipairs(sortedList) do
        for i = 1, 40 do
            local token = "nameplate"..i
            if UnitExists(token) then
                -- FIX 3: Use robust name reading
                local npName = StripRealm(UnitName(token) or "")
                if npName == d.name then
                    local npFrame = C_NamePlate and C_NamePlate.GetNamePlateForUnit(token)
                    if npFrame then
                        -- Try to get name via our helper as a sanity check
                        local frameName = GetNameplateName(npFrame)
                        Debug("nptest token="..token.." unitName="..npName.." frameName="..(frameName or "nil"))

                        local marker = GetOrCreateMarker(d.name)
                        local cc = GetClassColor(d.class)

                        -- Color the backdrop border by class, pulse red when healing
                        local br, bg2, bb = cc.r, cc.g, cc.b
                        if d.isHealing and (GetTime() - (d.lastHeal or 0)) < 3 then
                            br, bg2, bb = 1, 0.1, 0.1
                        end
                        if marker.SetBackdropBorderColor then
                            marker:SetBackdropBorderColor(br, bg2, bb, 1)
                        end

                        -- Rank label in class color
                        marker.lbl:SetText("|cff"..string.format("%02x%02x%02x", cc.r*255, cc.g*255, cc.b*255)..rank.."|r")

                        -- Position above nameplate frame
                        marker:ClearAllPoints()
                        marker:SetPoint("BOTTOM", npFrame, "TOP", 0, 2)
                        marker:Show()
                    end
                    break
                end
            end
        end
    end
end

-- ============================================================
-- ALERT FRAME CREATION
-- ============================================================
local function CreateAlertFrames()
    -- Healing alert (red)
    alertFrame = CreateFrame("Frame", "DeathMarkAlert", UIParent)
    alertFrame:SetSize(300, 30)
    alertFrame:SetPoint("TOP", UIParent, "TOP", 0, -120)
    alertFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    local abg = alertFrame:CreateTexture(nil, "BACKGROUND")
    abg:SetAllPoints()
    abg:SetTexture(0.4, 0, 0, 0.8)
    alertFrame.text = alertFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    alertFrame.text:SetAllPoints()
    alertFrame:Hide()

    -- Detected alert (yellow)
    detectedFrame = CreateFrame("Frame", "DeathMarkDetected", UIParent)
    detectedFrame:SetSize(300, 30)
    detectedFrame:SetPoint("TOP", UIParent, "TOP", 0, -155)
    detectedFrame:SetFrameStrata("FULLSCREEN_DIALOG")
    local dbg = detectedFrame:CreateTexture(nil, "BACKGROUND")
    dbg:SetAllPoints()
    dbg:SetTexture(0.3, 0.3, 0, 0.8)
    detectedFrame.text = detectedFrame:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    detectedFrame.text:SetAllPoints()
    detectedFrame:Hide()
end

-- ============================================================
-- OPTIONS PANEL
-- ============================================================
local function CreateOptionsPanel()
    DeathMarkOptions = CreateFrame("Frame", "DeathMarkOptions", UIParent)
    DeathMarkOptions:SetSize(250, 340)
    DeathMarkOptions:SetPoint("CENTER")
    DeathMarkOptions:SetFrameStrata("DIALOG")
    DeathMarkOptions:EnableMouse(true)
    DeathMarkOptions:SetMovable(true)
    DeathMarkOptions:RegisterForDrag("LeftButton")
    DeathMarkOptions:SetScript("OnDragStart", function(s) s:StartMoving() end)
    DeathMarkOptions:SetScript("OnDragStop",  function(s) s:StopMovingOrSizing() end)
    DeathMarkOptions:Hide()

    local bg = DeathMarkOptions:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetTexture(0.05, 0.05, 0.05, 0.95)

    local title = DeathMarkOptions:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    title:SetPoint("TOP", 0, -12)
    title:SetText("|cffff4444☩ DeathMark Options|r")

    -- Store refs for manual refresh on OnShow
    local checkboxes = {}

    local function MakeCheckbox(label, yOff, getter, setter)
        local cb = CreateFrame("CheckButton", nil, DeathMarkOptions, "UICheckButtonTemplate")
        cb:SetSize(24, 24)
        cb:SetPoint("TOPLEFT", 20, yOff)
        local lbl = DeathMarkOptions:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
        lbl:SetPoint("LEFT", cb, "RIGHT", 4, 0)
        lbl:SetText(label)
        cb.getter = getter
        cb:SetScript("OnClick", function(s) setter(s:GetChecked()) end)
        table.insert(checkboxes, cb)
        return cb
    end

    MakeCheckbox("Enable DeathMark",     -45,
        function() return DeathMarkDB.enabled end,
        function(v) DeathMarkDB.enabled = v end)
    MakeCheckbox("Sound Alerts",         -75,
        function() return DeathMarkDB.sound end,
        function(v) DeathMarkDB.sound = v end)
    MakeCheckbox("Chat Alerts",          -105,
        function() return DeathMarkDB.chatAlerts end,
        function(v) DeathMarkDB.chatAlerts = v end)
    MakeCheckbox("Highlight Nameplates", -135,
        function() return DeathMarkDB.nameplateColor end,
        function(v) DeathMarkDB.nameplateColor = v end)

    -- Nameplate tip note
    local npNote = DeathMarkOptions:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    npNote:SetPoint("TOPLEFT", 20, -160)
    npNote:SetWidth(210)
    npNote:SetJustifyH("LEFT")
    npNote:SetText("|cffff9900Note:|r |cffaaaaaa\"Highlight Nameplates\" requires enemy\nnameplates to be enabled in-game.\nV key (default) toggles nameplates.|r")

    -- Divider line
    local divider = DeathMarkOptions:CreateTexture(nil, "BACKGROUND")
    divider:SetSize(210, 1)
    divider:SetPoint("TOPLEFT", 20, -205)
    divider:SetTexture(0.4, 0.4, 0.4, 0.6)

    -- Reset HUD button
    local resetBtn = CreateFrame("Button", nil, DeathMarkOptions, "UIPanelButtonTemplate")
    resetBtn:SetSize(210, 24)
    resetBtn:SetPoint("TOPLEFT", 20, -215)
    resetBtn:SetText("Reset HUD to Center Screen")
    resetBtn:SetScript("OnClick", function()
        DeathMarkDB.hudX = nil
        DeathMarkDB.hudY = nil
        DeathMarkHUD:ClearAllPoints()
        DeathMarkHUD:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
    end)

    -- Clear list + Close
    local clearBtn = CreateFrame("Button", nil, DeathMarkOptions, "UIPanelButtonTemplate")
    clearBtn:SetSize(100, 24)
    clearBtn:SetPoint("BOTTOMLEFT", 20, 20)
    clearBtn:SetText("Clear List")
    clearBtn:SetScript("OnClick", function()
        healers = {}
        healCastCount = {}
    end)

    local closeBtn = CreateFrame("Button", nil, DeathMarkOptions, "UIPanelButtonTemplate")
    closeBtn:SetSize(100, 24)
    closeBtn:SetPoint("BOTTOMRIGHT", -20, 20)
    closeBtn:SetText("Close")
    closeBtn:SetScript("OnClick", function() DeathMarkOptions:Hide() end)

    -- Version label
    local verLabel = DeathMarkOptions:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    verLabel:SetPoint("BOTTOM", 0, 8)
    verLabel:SetText("|cff666666v"..VERSION.."|r")

    DeathMarkOptions:SetScript("OnShow", function(self)
        self:ClearAllPoints()
        self:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
        -- Explicitly refresh each stored checkbox
        for _, cb in ipairs(checkboxes) do
            cb:SetChecked(cb.getter())
        end
    end)
end

-- ============================================================
-- MAIN FRAME / EVENT HANDLER
-- ============================================================
local frame = CreateFrame("Frame", "DeathMarkMain", UIParent)
frame:RegisterEvent("ADDON_LOADED")
frame:RegisterEvent("PLAYER_ENTERING_WORLD")
frame:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
frame:RegisterEvent("NAME_PLATE_UNIT_ADDED")
frame:RegisterEvent("PLAYER_TARGET_CHANGED")
frame:RegisterEvent("UPDATE_BATTLEFIELD_SCORE")

-- OnUpdate ticker
local updateTimer   = 0
local UPDATE_FREQ   = 0.15  -- HUD refresh
local scanTimer     = 0
local SCAN_FREQ     = 1.5   -- unit token re-verify
local alertFadeFreq = 0.05

frame:SetScript("OnUpdate", function(self, elapsed)
    if not DeathMarkDB then return end

    -- Alert fade
    if alertFrame and alertFrame:IsShown() then
        alertFrame.fadeTimer = (alertFrame.fadeTimer or 0) - elapsed
        if alertFrame.fadeTimer <= 0 then alertFrame:Hide() end
    end
    if detectedFrame and detectedFrame:IsShown() then
        detectedFrame.fadeTimer = (detectedFrame.fadeTimer or 0) - elapsed
        if detectedFrame.fadeTimer <= 0 then detectedFrame:Hide() end
    end

    -- FIX 1: Retry scan timer
    if scanRetryCount > 0 then
        scanRetryTimer = scanRetryTimer - elapsed
        if scanRetryTimer <= 0 then
            Debug("Retry scan attempt #"..scanRetryCount)
            local ok = ScanBattlefieldRoster(true)
            scanRetryCount = scanRetryCount - 1
            if scanRetryCount > 0 then
                scanRetryTimer = SCAN_RETRY_DELAYS[#SCAN_RETRY_DELAYS - scanRetryCount + 1] or 8
            end
        end
    end

    -- Periodic scan / unit refresh
    scanTimer = scanTimer + elapsed
    if scanTimer >= SCAN_FREQ then
        scanTimer = 0
        if inBG and DeathMarkDB.enabled then
            for name, d in pairs(healers) do
                local unit = FindCurrentUnit(d)
                if unit then
                    -- Update HP
                    local hp    = UnitHealth(unit)
                    local hpMax = UnitHealthMax(unit)
                    if hp    and hp    > 0 then d.hp    = hp    end
                    if hpMax and hpMax > 0 then d.hpMax = hpMax end
                    -- Update mana
                    local mana    = UnitMana(unit)
                    local manaMax = UnitManaMax(unit)
                    if mana    then d.mana    = mana    end
                    if manaMax and manaMax > 0 then d.manaMax = manaMax end
                    -- Range
                    d.range = EstimateRange(unit)
                end
            end
            UpdateNameplateMarkers()
        end
    end

    -- HUD refresh
    updateTimer = updateTimer + elapsed
    if updateTimer >= UPDATE_FREQ then
        updateTimer = 0
        UpdateHUD()
    end
end)

frame:SetScript("OnEvent", function(self, event, ...)
    -- --------------------------------------------------------
    if event == "ADDON_LOADED" then
        local name = ...
        if name ~= ADDON_NAME then return end

        -- Init SavedVariables
        if not DeathMarkDB then DeathMarkDB = {} end
        for k, v in pairs(DB_DEFAULTS) do
            if DeathMarkDB[k] == nil then DeathMarkDB[k] = v end
        end
        -- Version reset
        if DeathMarkDB.addonVersion ~= VERSION then
            for k, v in pairs(DB_DEFAULTS) do DeathMarkDB[k] = v end
            DeathMarkDB.addonVersion = VERSION
        end

        CreateHUD()
        CreateAlertFrames()
        CreateOptionsPanel()

        -- Restore HUD position
        if DeathMarkDB.hudX and DeathMarkDB.hudY then
            DeathMarkHUD:ClearAllPoints()
            DeathMarkHUD:SetPoint("CENTER", UIParent, "CENTER", DeathMarkDB.hudX, DeathMarkDB.hudY)
        end

        print("|cffff4444DeathMark "..VERSION.."|r // Project Ascension's Bronzebeard Server")
        print("|cffffd700The PenFifteen Club\226\132\162|r  \226\128\148  |cffaaaaaa\"Your healer has been marked for death.\"|r")
        print("Right-click HUD or |cffffff00/dm|r")

    -- --------------------------------------------------------
    elseif event == "PLAYER_ENTERING_WORLD" then
        inBG = IsInBG()
        healers = {}
        healCastCount = {}
        friendlySet = {}
        bgInitialScanDone = false

        if inBG then
            Debug("Entered BG — queuing scan retries")
            scanRetryCount = MAX_SCAN_RETRIES
            scanRetryTimer = SCAN_RETRY_DELAYS[1]
            ScanBattlefieldRoster(true)
        end

    -- --------------------------------------------------------
    elseif event == "UPDATE_BATTLEFIELD_SCORE" then
        if inBG then
            -- Only refresh friendlySet — never add new healers mid-BG from scoreboard
            ScanBattlefieldRoster(false)
        end

    -- --------------------------------------------------------
    elseif event == "NAME_PLATE_UNIT_ADDED" then
        local unit = ...
        if not unit then return end
        local name = StripRealm(UnitName(unit) or "")
        if name == "" then return end
        if friendlySet[name] then return end

        -- If already a known healer, update unit token
        if healers[name] then
            healers[name].unit = unit
            local lvl = UnitLevel(unit)
            if lvl and lvl > 0 then healers[name].level = lvl end
            -- Check real class and evict if not actually a healer
            local _, cls = UnitClass(unit)
            if cls then
                cls = string.upper(cls)
                if not HEALER_CLASSES[cls] and healers[name].class == "UNKNOWN" then
                    Debug("Evicting non-healer "..name.." via nameplate (class: "..cls..")")
                    healers[name] = nil
                end
            end
        end

        -- FIX 3: Try to read class from nameplate frame
        local npFrame = C_NamePlate and C_NamePlate.GetNamePlateForUnit(unit)
        if npFrame then
            local frameName = GetNameplateName(npFrame)
            Debug("NAME_PLATE_UNIT_ADDED: unit="..unit.." unitName="..name.." frameName="..(frameName or "nil"))
        end

    -- --------------------------------------------------------
    elseif event == "PLAYER_TARGET_CHANGED" then
        if not UnitExists("target") then return end
        if UnitIsFriend("player", "target") then return end

        local name  = StripRealm(UnitName("target") or "")
        local cls   = select(2, UnitClass("target")) or ""
        local level = UnitLevel("target") or 0
        cls = string.upper(cls)

        -- Update existing healer
        if healers[name] then
            if cls ~= "" then
                -- If we now know their real class and it's NOT a healer, remove them
                if not HEALER_CLASSES[cls] and healers[name].class == "UNKNOWN" then
                    Debug("Evicting non-healer "..name.." (real class: "..cls..")")
                    healers[name] = nil
                    return
                end
                healers[name].class = cls
            end
            if level > 0  then healers[name].level = level end
            healers[name].unit = "target"
            local hp    = UnitHealth("target")
            local hpMax = UnitHealthMax("target")
            if hp    and hp    > 0 then healers[name].hp    = hp    end
            if hpMax and hpMax > 0 then healers[name].hpMax = hpMax end
            local mana    = UnitMana("target")
            local manaMax = UnitManaMax("target")
            if mana              then healers[name].mana    = mana    end
            if manaMax and manaMax > 0 then healers[name].manaMax = manaMax end
        end

        -- If targeting a healer class not yet detected
        if HEALER_CLASSES[cls] and not healers[name] and not friendlySet[name] then
            AddHealer(name, cls, level, "target")
        end

    -- --------------------------------------------------------
    elseif event == "COMBAT_LOG_EVENT_UNFILTERED" then
        if not inBG then return end
        if not DeathMarkDB.enabled then return end

        local args = {...}
        local subevent   = args[2]
        local sourceName = args[4]
        local sourceFlags= args[5]
        local spellName  = args[12]

        -- Only process heal events
        if subevent ~= "SPELL_HEAL"
        and subevent ~= "SPELL_AURA_HEAL"
        and subevent ~= "SPELL_PERIODIC_HEAL"
        and subevent ~= "SPELL_CAST_SUCCESS"
        and subevent ~= "SPELL_CAST_START" then
            return
        end

        if not sourceName then return end
        local stripped = StripRealm(sourceName)
        if stripped == "" then return end

        -- Skip friendly
        if friendlySet[stripped] then return end
        -- Skip self
        if stripped == StripRealm(UnitName("player") or "") then return end

        -- Must be hostile
        local isHostile = bit.band(sourceFlags or 0, COMBATLOG_OBJECT_REACTION_HOSTILE) ~= 0
        if not isHostile then return end

        -- Must be a player — filters out NPC/mob heals (Environment, Sanitar, beasts, etc.)
        local isPlayer = bit.band(sourceFlags or 0, COMBATLOG_OBJECT_TYPE_PLAYER) ~= 0
        if not isPlayer then return end

        -- FIX 2: Use fallback counter for unknown-class healers
        if healers[stripped] then
            MarkHealing(stripped)
        else
            HandleCombatLogHeal(stripped, spellName)
        end
    end
end)

-- ============================================================
-- SLASH COMMANDS
-- ============================================================
SLASH_DEATHMARK1 = "/dm"
SLASH_DEATHMARK2 = "/deathmark"
SlashCmdList["DEATHMARK"] = function(msg)
    msg = string.trim(msg or ""):lower()

    if msg == "" then
        if DeathMarkOptions then
            if DeathMarkOptions:IsShown() then
                DeathMarkOptions:Hide()
            else
                DeathMarkOptions:Show()
            end
        end

    elseif msg == "scan" then
        healers = {}
        healCastCount = {}
        bgInitialScanDone = false
        local ok = ScanBattlefieldRoster(true)
        print("|cffff4444[DeathMark]|r Manual scan complete. Found "..(ok and "scores" or "0 (empty scoreboard)"))

    elseif msg == "debug" then
        DeathMarkDB.debug = not DeathMarkDB.debug
        print("|cffff4444[DeathMark]|r Debug "..(DeathMarkDB.debug and "ON" or "OFF"))

    elseif msg == "list" then
        local count = 0
        for name, d in pairs(healers) do
            print("|cffff4444[DM]|r "..name.." | "..d.class.." | lvl "..(d.level>0 and d.level or "??").." | range "..(d.range<999 and "~"..d.range.."y" or "?y"))
            count = count + 1
        end
        if count == 0 then print("|cffff4444[DeathMark]|r No healers detected.") end

    elseif msg == "hud" then
        DeathMarkDB.hudVisible = not DeathMarkDB.hudVisible
        print("|cffff4444[DeathMark]|r HUD "..(DeathMarkDB.hudVisible and "shown" or "hidden"))

    elseif msg == "clear" then
        healers = {}
        healCastCount = {}
        print("|cffff4444[DeathMark]|r Healer list cleared.")

    elseif msg == "nptest" then
        print("|cffff4444[DeathMark]|r --- Nameplate Test ---")
        if C_NamePlate then
            print("C_NamePlate API: AVAILABLE")
        else
            print("C_NamePlate API: NOT FOUND")
        end
        local found = 0
        for i = 1, 40 do
            local token = "nameplate"..i
            if UnitExists(token) then
                found = found + 1
                local npFrame = C_NamePlate and C_NamePlate.GetNamePlateForUnit(token)
                local unitName = StripRealm(UnitName(token) or "")
                if npFrame then
                    local frameName = GetNameplateName(npFrame)
                    print(token.." -> frame: "..tostring(npFrame).." unitName="..unitName.." frameName="..(frameName or "nil"))
                else
                    print(token.." -> no frame | unitName="..unitName)
                end
            end
        end
        if found == 0 then print("No active nameplates found.") end
        -- Also dump G nameplate search
        local gFound = 0
        for k, v in pairs(_G) do
            if type(k) == "string" and string.lower(k):find("nameplate") then
                gFound = gFound + 1
                if gFound <= 5 then print("_G key: "..k) end
            end
        end
        print("_G nameplate keys found: "..gFound)

    else
        print("|cffff4444[DeathMark]|r Commands: scan, debug, list, hud, clear, nptest")
    end
end
