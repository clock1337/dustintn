# DeathMark v1.53
PvP Healer Detection HUD — Project Ascension 3.3.5a

## Versions
- **DeathMark_Bronzebeard** — class-based realm. Detects healer classes only.
- **DeathMark_A52** — classless realm. Detects anyone casting heals.

## Install
Copy the appropriate folder to:
`Ascension Launcher > resources > client > Interface > AddOns > DeathMark_Bronzebeard`

## Slash Commands
- `/dm` — open options panel
- `/dm scan` — manual scoreboard scan
- `/dm debug` — toggle debug output
- `/dm list` — print healer list to chat
- `/dm nptest` — nameplate frame detection test (run in BG with enemy nameplates visible)
- `/dm clear` — clear healer list
- `/dm hud` — toggle HUD visibility

## Reset HUD position (in-game)
```
/script DeathMarkDB.hudX = nil; DeathMarkDB.hudY = nil; DeathMarkHUD:ClearAllPoints(); DeathMarkHUD:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
```

## v1.53 Changes
1. **Scoreboard scan retries** — queues 3 retries at 3s, 8s, 15s after BG entry to catch late-populating rosters
2. **Combat log fallback** — unknown-class players flagged after 2 heals (BB) or 1 heal (A52) instead of being silently skipped
3. **Nameplate name detection** — tries 4 different frame paths to read player name from C_NamePlate frames (fixes `name=?` in nptest output)
