-- QuiverKeeper.lua  v1.9.0 // ArathiBasin
-- Hunter ammo + pet food tracker for Project Ascension (WoW 3.3.5)
-- Right-click either HUD  OR  /qk  to open options
-- /qk debug  for diagnostics

local ADDON     = "QuiverKeeper"
local VERSION   = "1.9.0"
local CODENAME  = "ArathiBasin"    -- patch codename, update each release
local PREFIX    = "|cff00ccff[QuiverKeeper]|r"

QuiverKeeperConfig = QuiverKeeperConfig or {
    warnYellow    = 200,
    warnRed       = 100,
    scale         = 1.0,
    posX          = nil,
    posY          = nil,
    locked        = false,
    showLabel     = true,
    flashZero     = true,
    chatWarning   = true,
    petEnabled    = true,
    petWarnYellow = 5,
    petWarnRed    = 2,
    petPosX       = nil,
    petPosY       = nil,
    petMagnetic   = true,
}

-- ─────────────────────────────────────────────
--  Chat helper
-- ─────────────────────────────────────────────
local function MSG(text)
    DEFAULT_CHAT_FRAME:AddMessage(text)
end

local function MSGD(text)  -- debug output
    DEFAULT_CHAT_FRAME:AddMessage("|cffffff00[QK Debug]|r " .. tostring(text))
end

-- ─────────────────────────────────────────────
--  Pet food keyword table
--  WoW 3.3.5: all food items = type "Consumable", subtype "Food & Drink"
--  We identify what pet can eat by matching item names against keywords.
-- ─────────────────────────────────────────────
local FOOD_KEYWORDS = {
    Meat = {
        "mutton","chop","roast","haunch","meat","steak","flesh","ribs",
        "venison","boar","chunk","raw bear","spider leg","crab claw",
        "crocolisk","basilisk","raptor egg","buzzard","tiger","lion",
        "wolf","bear","clam meat","crawler","crag boar","thick","lean",
        "rich","stringy","boar intestines","mystery meat","tender wolf",
        "dried king bolete","succulent","roasted","smoked",
    },
    Fish = {
        "fish","salmon","trout","snapper","grouper","carp","bass","cod",
        "mightfish","nightfin","sunscale","firefin","oily blackmouth",
        "spotted yellowtail","deviate fish","speckled tastyfish",
        "raw rainbow fin","raw rockscale","raw whitescale",
    },
    Bread = {
        "bread","biscuit","roll","loaf","muffin","corn","wheat",
        "pumpernickel","freshly baked","conjured bread","hardtack",
    },
    Cheese = {
        "cheese","cheddar","gouda","brie","darnassian bleu",
        "alterac swiss","fine aged cheddar","dalaran sharp",
    },
    Fruit = {
        "apple","banana","mango","melon","pear","cherry","plum","peach",
        "tel'abim","shiny red","goldenbark","moonberry juice",
    },
    Fungus = {
        "fungus","mushroom","truffle","spore","dried king bolete",
        "delicious cave mold","raw black truffle",
    },
}

local FAMILY_ACCEPTS = {
    ["Bat"]          = {"Meat","Fish"},
    ["Bear"]         = {"Meat","Fish","Bread","Cheese","Fruit","Fungus"},
    ["Bird of Prey"] = {"Meat","Fish"},
    ["Boar"]         = {"Meat","Fish","Bread","Cheese","Fruit","Fungus"},
    ["Carrion Bird"] = {"Meat","Fish"},
    ["Cat"]          = {"Meat","Fish"},
    ["Crab"]         = {"Fish","Bread","Cheese","Fruit","Fungus"},
    ["Crocolisk"]    = {"Meat","Fish"},
    ["Gorilla"]      = {"Fruit","Fungus"},
    ["Hyena"]        = {"Meat","Fish"},
    ["Owl"]          = {"Meat","Fish"},
    ["Raptor"]       = {"Meat","Fish"},
    ["Scorpid"]      = {"Meat"},
    ["Spider"]       = {"Meat"},
    ["Tallstrider"]  = {"Fruit","Fungus","Bread"},
    ["Turtle"]       = {"Fish","Fruit","Fungus"},
    ["Warp Stalker"] = {"Meat","Fish"},
    ["Wolf"]         = {"Meat","Fish"},
    ["Worm"]         = {"Bread","Cheese","Fungus"},
    ["Wind Serpent"] = {"Meat","Fish"},
    ["Nether Ray"]   = {"Meat","Fish"},
    ["Silithid"]     = {"Meat","Fish"},
    ["Wasp"]         = {"Meat","Fish"},
}

local VENDOR_HINTS = {
    Meat = {
        "Xar'Ti – The Crossroads, Barrens (Horde)",
        "Borya – Orgrimmar, Valley of Strength (Horde)",
        "Felika – Crossroads (Roasted Boar Meat)",
        "Gothard Winespar – Undercity (Horde)",
        "Innkeeper Renee Lauer – Goldshire (Alliance)",
    },
    Fish = {
        "Tansy Puddlefizz – Lakeshire, Redridge",
        "Zarena Cromwind – Booty Bay (neutral)",
        "Kendor Kabonka – Old Town, Stormwind (Alliance)",
    },
    Bread  = { "Most innkeepers sell Freshly Baked Bread" },
    Cheese = { "Most innkeepers sell Alterac Swiss / other cheeses" },
    Fruit  = { "Most innkeepers sell Shiny Red Apple / Tel'Abim Banana" },
    Fungus = { "Undercity vendors near the bank (Horde)", "Remy 'Two Fangs' – Hillsbrad" },
}

local AMMO_VENDORS = {
    arrows = {
        "Keldran – Orgrimmar, Valley of Strength (Horde)",
        "Xorb the Grotesque – Undercity (Horde)",
        "Hammon Karwn – Ironforge (Alliance)",
        "Zixil – Shimmering Flats, Thousand Needles (neutral)",
    },
    bullets = {
        "Ssildra Tok – Undercity (Horde)",
        "Lina Hearthstove – Ironforge (Alliance)",
        "Keldran – Orgrimmar (Horde)",
        "Zarena Cromwind – Booty Bay (neutral)",
    },
}

-- ─────────────────────────────────────────────
--  Food matching
-- ─────────────────────────────────────────────
local function BuildKeywordSet(family)
    local accepts = FAMILY_ACCEPTS[family]
    if not accepts then return nil, nil end
    local kws = {}
    for _, cat in ipairs(accepts) do
        for _, kw in ipairs(FOOD_KEYWORDS[cat] or {}) do
            kws[kw] = cat
        end
    end
    return kws, accepts
end

local function NameMatchesKeywords(name, kws)
    if not name or not kws then return false end
    local lower = name:lower()
    for kw in pairs(kws) do
        if lower:find(kw, 1, true) then return true end
    end
    return false
end

-- ─────────────────────────────────────────────
--  Ammo scan
-- ─────────────────────────────────────────────
local function GetAmmoInfo()
    local count = GetInventoryItemCount("player", 0) or 0
    local link  = GetInventoryItemLink("player", 0)
    local name  = link and GetItemInfo(link) or nil
    if count == 0 then
        for bag = 0, 4 do
            for slot = 1, GetContainerNumSlots(bag) do
                local lnk = GetContainerItemLink(bag, slot)
                if lnk then
                    local n,_,_,_,_,t = GetItemInfo(lnk)
                    if t == "Projectile" then
                        local _,c = GetContainerItemInfo(bag, slot)
                        if c and c > count then count=c; name=n end
                    end
                end
            end
        end
    end
    return count, name
end

-- ─────────────────────────────────────────────
--  Pet food scan
-- ─────────────────────────────────────────────
local function GetPetFoodInfo()
    local family = UnitCreatureFamily("pet")
    if not family then return 0, nil, nil, nil end
    local kws, accepts = BuildKeywordSet(family)
    if not kws then return 0, family, nil, nil end

    local total, firstName = 0, nil
    for bag = 0, 4 do
        for slot = 1, GetContainerNumSlots(bag) do
            local lnk = GetContainerItemLink(bag, slot)
            if lnk then
                local n,_,_,_,_,t,s = GetItemInfo(lnk)
                local isFood = (t == "Consumable") and (s == "Food & Drink" or s == "Food")
                if isFood and NameMatchesKeywords(n, kws) then
                    local _,c = GetContainerItemInfo(bag, slot)
                    if c then total=total+c; if not firstName then firstName=n end end
                end
            end
        end
    end
    return total, family, firstName, accepts
end

-- ─────────────────────────────────────────────
--  HUD factory
-- ─────────────────────────────────────────────
local BASE_W = 160
local BASE_H = 90
local BASE_FONT_BIG   = 42
local BASE_FONT_LABEL = 11
local BASE_FONT_HINT  = 9

local function MakeHUD(fname, dx, dy)
    local f = CreateFrame("Frame", fname, UIParent)
    f:SetWidth(BASE_W); f:SetHeight(BASE_H); f:SetFrameStrata("MEDIUM")
    f:EnableMouse(true); f:SetMovable(true)
    f:RegisterForDrag("LeftButton"); f:SetClampedToScreen(true)
    f:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", dx, dy)

    f.bg = f:CreateTexture(nil,"BACKGROUND"); f.bg:SetAllPoints(f); f.bg:SetTexture(0,0,0,0.45)
    local tl = f:CreateTexture(nil,"BORDER"); tl:SetHeight(1)
    tl:SetPoint("TOPLEFT",f,"TOPLEFT",0,0); tl:SetPoint("TOPRIGHT",f,"TOPRIGHT",0,0)
    tl:SetTexture(1,1,1,0.15)

    f.label = f:CreateFontString(nil,"OVERLAY")
    f.label:SetPoint("TOP",f,"TOP",0,-6)
    f.label:SetFont("Fonts\\FRIZQT__.TTF",BASE_FONT_LABEL,"OUTLINE")
    f.label:SetTextColor(0.8,0.8,0.8,0.9); f.label:SetText("---")

    f.count = f:CreateFontString(nil,"OVERLAY")
    f.count:SetPoint("CENTER",f,"CENTER",0,-6)
    f.count:SetFont("Fonts\\FRIZQT__.TTF",BASE_FONT_BIG,"OUTLINE")
    f.count:SetTextColor(1,1,1,0.95); f.count:SetText("---")

    f.hint = f:CreateFontString(nil,"OVERLAY")
    f.hint:SetPoint("BOTTOMRIGHT",f,"BOTTOMRIGHT",-4,3)
    f.hint:SetFont("Fonts\\FRIZQT__.TTF",BASE_FONT_HINT,"OUTLINE")
    f.hint:SetTextColor(0.5,0.5,0.5,0.5); f.hint:SetText("move")

    -- Resize grip — subtle L-shaped corner lines instead of a white square
    local grip = CreateFrame("Frame", nil, f)
    grip:SetWidth(16); grip:SetHeight(16)
    grip:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -1, 1)
    grip:EnableMouse(true)
    -- Horizontal line of the L
    local gH = grip:CreateTexture(nil,"OVERLAY")
    gH:SetHeight(2); gH:SetWidth(10)
    gH:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", 0, 0)
    gH:SetTexture(1,1,1,0.35)
    -- Vertical line of the L
    local gV = grip:CreateTexture(nil,"OVERLAY")
    gV:SetWidth(2); gV:SetHeight(10)
    gV:SetPoint("BOTTOMRIGHT", grip, "BOTTOMRIGHT", 0, 0)
    gV:SetTexture(1,1,1,0.35)
    -- Brighten on hover
    grip:SetScript("OnEnter", function()
        gH:SetTexture(1,1,0.4,0.8); gV:SetTexture(1,1,0.4,0.8)
        GameTooltip:SetOwner(grip,"ANCHOR_TOP")
        GameTooltip:SetText("|cff00ccffQuiverKeeper|r",1,1,1)
        GameTooltip:AddLine("Drag to resize",0.8,0.8,0.8)
        GameTooltip:Show()
    end)
    grip:SetScript("OnLeave", function()
        gH:SetTexture(1,1,1,0.35); gV:SetTexture(1,1,1,0.35)
        GameTooltip:Hide()
    end)
    -- Resize drag
    grip:SetScript("OnMouseDown", function(self, btn)
        if btn=="LeftButton" and not QuiverKeeperConfig.locked then
            f.resizing = true
            f.resizeStartX, f.resizeStartY = GetCursorPosition()
            f.resizeStartW = f:GetWidth()
            f.resizeStartH = f:GetHeight()
        end
    end)
    grip:SetScript("OnMouseUp", function(self, btn)
        if btn=="LeftButton" and f.resizing then
            f.resizing = false
            -- Save scale based on final width
            QuiverKeeperConfig.scale = f:GetWidth() / BASE_W
            -- Re-snap if magnetic was on
            if QuiverKeeperConfig.petMagnetic then ApplyMagnetic() end
        end
    end)
    f.grip = grip

    f.pulseTimer=0; f.isPulsing=false
    return f
end

local ammoHUD = MakeHUD("QKAmmoFrame",   -220, 120)
local petHUD  = MakeHUD("QKPetFrame",    -220, 20)
local opt  -- forward declared; assigned below after CreateFrame

-- ─────────────────────────────────────────────
--  Drag scripts
-- ─────────────────────────────────────────────
ammoHUD:SetScript("OnMouseDown", function(self, btn)
    if btn=="LeftButton" and not QuiverKeeperConfig.locked then
        self:StartMoving()
    end
end)
ammoHUD:SetScript("OnMouseUp", function(self, btn)
    if btn=="LeftButton" then
        self:StopMovingOrSizing()
        local _,_,_,x,y = self:GetPoint()
        QuiverKeeperConfig.posX=x; QuiverKeeperConfig.posY=y
        -- Re-anchor pet to new ammo position
        if QuiverKeeperConfig.petMagnetic then
            ApplyMagnetic()
        end
    elseif btn=="RightButton" then
        if opt:IsShown() then opt:Hide() else opt:Show() end
    end
end)

petHUD:SetScript("OnMouseDown", function(self, btn)
    if btn=="LeftButton" and not QuiverKeeperConfig.locked then
        -- GetCenter() returns UIParent-space coords directly (both HUDs parented to UIParent)
        -- No scale conversion needed
        local px, py = self:GetCenter()
        self:ClearAllPoints()
        self:SetPoint("CENTER", UIParent, "BOTTOMLEFT", px, py)
        QuiverKeeperConfig.petMagnetic = false
        self:StartMoving()
    end
end)
petHUD:SetScript("OnMouseUp", function(self, btn)
    if btn=="LeftButton" then
        self:StopMovingOrSizing()
        if not TrySnap() then
            local _,_,_,x,y = self:GetPoint()
            QuiverKeeperConfig.petPosX=x; QuiverKeeperConfig.petPosY=y
            QuiverKeeperConfig.petMagnetic=false
        end
    elseif btn=="RightButton" then
        if opt:IsShown() then opt:Hide() else opt:Show() end
    end
end)

-- ─────────────────────────────────────────────
--  HUD color/text update helpers
-- ─────────────────────────────────────────────
local function ColorHUD(hud, count, warnRed, warnYellow, flash)
    if count == 0 then
        hud.count:SetTextColor(1,0.1,0.1,1); hud.bg:SetTexture(0.4,0,0,0.55)
        hud.isPulsing = flash
    elseif count <= warnRed then
        hud.count:SetTextColor(1,0.2,0.2,0.95); hud.bg:SetTexture(0.25,0,0,0.5)
        hud.isPulsing = false
    elseif count <= warnYellow then
        hud.count:SetTextColor(1,0.85,0.1,0.95); hud.bg:SetTexture(0.2,0.15,0,0.5)
        hud.isPulsing = false
    else
        -- Green = healthy / well stocked
        hud.count:SetTextColor(0.4,1,0.5,0.95); hud.bg:SetTexture(0,0.15,0,0.45)
        hud.isPulsing = false
    end
end

local function UpdateAmmoHUD()
    local cfg = QuiverKeeperConfig
    local count, name = GetAmmoInfo()
    ammoHUD.count:SetText(count >= 1000
        and string.format("%d,%03d", math.floor(count/1000), count%1000)
        or  tostring(count))
    if cfg.showLabel then
        ammoHUD.label:SetText(name and (name:match("^(%S+)") or name):upper() or "AMMO")
        ammoHUD.label:Show()
    else ammoHUD.label:Hide() end
    ColorHUD(ammoHUD, count, cfg.warnRed, cfg.warnYellow, cfg.flashZero)
    ammoHUD.hint:SetText(cfg.locked and "" or "move")
end

local function UpdatePetHUD()
    local cfg = QuiverKeeperConfig
    if not cfg.petEnabled then petHUD:Hide(); return end
    petHUD:Show()
    if not UnitExists("pet") then
        petHUD.label:SetText("NO PET")
        petHUD.count:SetText("")
        petHUD.count:SetTextColor(0.4,0.4,0.4,0.5)
        petHUD.bg:SetTexture(0,0,0,0.25)
        petHUD.isPulsing=false
        petHUD.hint:SetText(cfg.locked and "" or "move")
        return
    end
    local count, family = GetPetFoodInfo()
    petHUD.label:SetText((family or "PET"):upper().." FOOD")
    petHUD.count:SetText(tostring(count))
    ColorHUD(petHUD, count, cfg.petWarnRed, cfg.petWarnYellow, cfg.flashZero)
    petHUD.hint:SetText(cfg.locked and "" or "move")
end

-- ─────────────────────────────────────────────
--  Magnetic / position
--  petMagSide = "BOTTOM","TOP","LEFT","RIGHT" or nil
-- ─────────────────────────────────────────────

-- Apply the stored snap side (or default BOTTOM)
local function ApplyMagnetic()
    local cfg = QuiverKeeperConfig
    if not cfg.petMagnetic or not cfg.petEnabled then return end
    local side = cfg.petMagSide or "BOTTOM"
    petHUD:ClearAllPoints()
    if side == "BOTTOM" then
        petHUD:SetPoint("TOP",    ammoHUD, "BOTTOM", 0, -4)
    elseif side == "TOP" then
        petHUD:SetPoint("BOTTOM", ammoHUD, "TOP",    0,  4)
    elseif side == "LEFT" then
        petHUD:SetPoint("RIGHT",  ammoHUD, "LEFT",  -4,  0)
    elseif side == "RIGHT" then
        petHUD:SetPoint("LEFT",   ammoHUD, "RIGHT",  4,  0)
    end
end

local SNAP_DIST = 120  -- UIParent units — how close to trigger snap

local function TrySnap()
    -- GetCenter() returns UIParent-space coords for both frames (same parent)
    local ax, ay = ammoHUD:GetCenter()
    local px, py = petHUD:GetCenter()
    -- Frame dimensions are also in UIParent space (no scale needed since SetScale removed)
    local aw = ammoHUD:GetWidth()
    local ah = ammoHUD:GetHeight()

    -- Midpoint of each edge of the ammo HUD
    local edges = {
        BOTTOM = { x=ax,      y=ay-ah/2 },
        TOP    = { x=ax,      y=ay+ah/2 },
        LEFT   = { x=ax-aw/2, y=ay      },
        RIGHT  = { x=ax+aw/2, y=ay      },
    }

    local bestSide, bestDist = nil, math.huge
    for side, pt in pairs(edges) do
        local d = math.sqrt((px-pt.x)^2 + (py-pt.y)^2)
        if d < bestDist then bestDist=d; bestSide=side end
    end

    if bestDist <= SNAP_DIST then
        QuiverKeeperConfig.petMagnetic = true
        QuiverKeeperConfig.petMagSide  = bestSide
        ApplyMagnetic()
        MSG(PREFIX.." Snapped ("..bestSide.."). Drag far away to detach.")
        return true
    end
    return false
end

local function ResizeHUD(hud, s)
    local w = math.floor(BASE_W * s + 0.5)
    local h = math.floor(BASE_H * s + 0.5)
    hud:SetWidth(w); hud:SetHeight(h)
    hud.count:SetFont("Fonts\\FRIZQT__.TTF", math.max(8, math.floor(BASE_FONT_BIG   * s + 0.5)), "OUTLINE")
    hud.label:SetFont("Fonts\\FRIZQT__.TTF", math.max(6, math.floor(BASE_FONT_LABEL * s + 0.5)), "OUTLINE")
    hud.hint:SetFont( "Fonts\\FRIZQT__.TTF", math.max(6, math.floor(BASE_FONT_HINT  * s + 0.5)), "OUTLINE")
end

local function ApplyScale()
    local s = QuiverKeeperConfig.scale
    ResizeHUD(ammoHUD, s)
    ResizeHUD(petHUD,  s)
    -- Re-apply magnetic so the gap stays correct after resize
    if QuiverKeeperConfig.petMagnetic then ApplyMagnetic() end
end

local function RestorePositions()
    local cfg = QuiverKeeperConfig
    -- Ammo HUD always placed first so magnetic anchor exists
    ammoHUD:ClearAllPoints()
    if cfg.posX and cfg.posY then
        ammoHUD:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", cfg.posX, cfg.posY)
    else
        ammoHUD:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", -220, 120)
    end
    -- Pet HUD: magnetic (any side) or saved position or default snapped below
    petHUD:ClearAllPoints()
    if cfg.petMagnetic then
        ApplyMagnetic()
    elseif cfg.petPosX and cfg.petPosY then
        petHUD:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT", cfg.petPosX, cfg.petPosY)
    else
        -- First ever load — default snap below
        cfg.petMagnetic = true
        cfg.petMagSide  = "BOTTOM"
        ApplyMagnetic()
    end
end

-- pulse + resize OnUpdate
local ammoT, petT = 0, 0
ammoHUD:SetScript("OnUpdate", function(self,dt)
    if self.resizing then
        local cx, cy = GetCursorPosition()
        local uiScale = UIParent:GetEffectiveScale()
        local dx = (cx - self.resizeStartX) / uiScale
        local dy = (self.resizeStartY - cy) / uiScale
        local newW = math.max(80, self.resizeStartW + dx)
        local newH = math.max(50, self.resizeStartH + dy)
        self:SetWidth(newW); self:SetHeight(newH)
        local s = newW / BASE_W
        self.count:SetFont("Fonts\\FRIZQT__.TTF", math.max(8,  math.floor(BASE_FONT_BIG   * s + 0.5)), "OUTLINE")
        self.label:SetFont("Fonts\\FRIZQT__.TTF", math.max(6,  math.floor(BASE_FONT_LABEL * s + 0.5)), "OUTLINE")
        self.hint:SetFont( "Fonts\\FRIZQT__.TTF", math.max(6,  math.floor(BASE_FONT_HINT  * s + 0.5)), "OUTLINE")
        -- Keep pet snapped while resizing ammo
        if QuiverKeeperConfig.petMagnetic then ApplyMagnetic() end
        return
    end
    ammoT=ammoT+dt
    if ammoT>=0.5 then ammoT=0; UpdateAmmoHUD() end
    if self.isPulsing then
        self.pulseTimer=self.pulseTimer+dt
        self.count:SetAlpha(0.6+0.4*math.abs(math.sin(self.pulseTimer*3)))
    else self.pulseTimer=0; self.count:SetAlpha(1) end
end)
petHUD:SetScript("OnUpdate", function(self,dt)
    if self.resizing then
        local cx, cy = GetCursorPosition()
        local uiScale = UIParent:GetEffectiveScale()
        local dx = (cx - self.resizeStartX) / uiScale
        local dy = (self.resizeStartY - cy) / uiScale
        local newW = math.max(80, self.resizeStartW + dx)
        local newH = math.max(50, self.resizeStartH + dy)
        self:SetWidth(newW); self:SetHeight(newH)
        local s = newW / BASE_W
        self.count:SetFont("Fonts\\FRIZQT__.TTF", math.max(8,  math.floor(BASE_FONT_BIG   * s + 0.5)), "OUTLINE")
        self.label:SetFont("Fonts\\FRIZQT__.TTF", math.max(6,  math.floor(BASE_FONT_LABEL * s + 0.5)), "OUTLINE")
        self.hint:SetFont( "Fonts\\FRIZQT__.TTF", math.max(6,  math.floor(BASE_FONT_HINT  * s + 0.5)), "OUTLINE")
        return
    end
    petT=petT+dt
    if petT>=1.0 then petT=0; UpdatePetHUD() end
    if self.isPulsing then
        self.pulseTimer=self.pulseTimer+dt
        self.count:SetAlpha(0.6+0.4*math.abs(math.sin(self.pulseTimer*3)))
    else self.pulseTimer=0; self.count:SetAlpha(1) end
end)

-- ─────────────────────────────────────────────
--  Vendor printer
-- ─────────────────────────────────────────────
local function PrintVendors()
    local _, ammoName = GetAmmoInfo()
    local atype = "arrows"
    if ammoName then
        local l = ammoName:lower()
        if l:find("bullet") or l:find("shot") or l:find("slug") then atype="bullets" end
    end
    MSG(PREFIX.." Ammo vendors ("..atype.."):")
    for _,v in ipairs(AMMO_VENDORS[atype]) do MSG("  |cffffff00»|r "..v) end
    local _,family,_,accepts = GetPetFoodInfo()
    if family and accepts then
        MSG(PREFIX.." Your |cffff9900"..family.."|r eats: |cffffffff"..table.concat(accepts,", ").."|r")
        local shown={}
        for _,cat in ipairs(accepts) do
            local hints=VENDOR_HINTS[cat]
            if hints then
                MSG("  |cffaaddff["..cat.."]|r")
                for _,v in ipairs(hints) do
                    if not shown[v] then MSG("    |cffffff00»|r "..v); shown[v]=true end
                end
            end
        end
    else
        MSG(PREFIX.." Summon your pet to see food vendor info.")
    end
end

-- ─────────────────────────────────────────────
--  Debug command
-- ─────────────────────────────────────────────
local function RunDebug()
    local cfg = QuiverKeeperConfig
    MSGD("=== QuiverKeeper v"..VERSION.." Debug ===")
    MSGD("Ammo count: "..GetAmmoInfo())
    MSGD("Ammo warn yellow/red: "..cfg.warnYellow.." / "..cfg.warnRed)

    local petCount, family, foodName, accepts = GetPetFoodInfo()
    MSGD("Pet active: "..(UnitExists("pet") and "YES" or "NO"))
    MSGD("Pet family: "..(family or "nil"))
    MSGD("Pet food count: "..petCount)
    MSGD("Pet food name found: "..(foodName or "nil"))
    MSGD("Pet accepts: "..(accepts and table.concat(accepts,", ") or "nil"))
    MSGD("Pet warn yellow/red: "..cfg.petWarnYellow.." / "..cfg.petWarnRed)
    MSGD("Scale: "..cfg.scale)
    MSGD("Magnetic: "..(cfg.petMagnetic and "true" or "false"))
    MSGD("Locked: "..(cfg.locked and "true" or "false"))

    -- Scan bags and print all food found
    MSGD("--- Bag food scan (Consumable / Food & Drink) ---")
    local fcount = 0
    for bag=0,4 do
        for slot=1,GetContainerNumSlots(bag) do
            local lnk = GetContainerItemLink(bag,slot)
            if lnk then
                local n,_,_,_,_,t,s = GetItemInfo(lnk)
                if t=="Consumable" then
                    local _,c = GetContainerItemInfo(bag,slot)
                    MSGD("  ["..bag..","..slot.."] "..tostring(n).." | type="..tostring(t).." sub="..tostring(s).." x"..tostring(c))
                    fcount=fcount+1
                    if fcount >= 15 then MSGD("  (truncated at 15 items)"); return end
                end
            end
        end
    end
    if fcount==0 then MSGD("  No consumable items found in bags.") end
    MSGD("=== end debug ===")
end

-- ─────────────────────────────────────────────
--  Bag icon border highlight + tooltip injection
--  Shows a colored border on items your pet eats,
--  and adds "Your pet eats this!" to their tooltip.
-- ─────────────────────────────────────────────

-- Cache of itemName -> true for current pet's food
local petFoodCache = {}
local petFoodCacheFamily = nil

local function RebuildFoodCache()
    local family = UnitCreatureFamily("pet")
    if family == petFoodCacheFamily then return end  -- no change
    petFoodCacheFamily = family
    petFoodCache = {}
    if not family then return end
    local kws = BuildKeywordSet(family)
    if not kws then return end
    -- Scan bags and cache matching item names
    for bag=0,4 do
        for slot=1,GetContainerNumSlots(bag) do
            local lnk = GetContainerItemLink(bag,slot)
            if lnk then
                local n,_,_,_,_,t,s = GetItemInfo(lnk)
                local isFood = (t=="Consumable") and (s=="Food & Drink" or s=="Food")
                if isFood and NameMatchesKeywords(n, kws) then
                    petFoodCache[n] = true
                end
            end
        end
    end
end

-- Overlay frames: one per bag slot button (lazy created)
local overlayFrames = {}

local function GetOrCreateOverlay(bagSlotFrame, key)
    if overlayFrames[key] then return overlayFrames[key] end
    local ov = CreateFrame("Frame", nil, bagSlotFrame)
    ov:SetAllPoints(bagSlotFrame)
    ov:SetFrameLevel(bagSlotFrame:GetFrameLevel() + 5)
    -- Bright teal/green border texture using WoW's standard highlight
    local tex = ov:CreateTexture(nil, "OVERLAY")
    tex:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    tex:SetBlendMode("ADD")
    tex:SetVertexColor(0.2, 1.0, 0.4, 0.9)
    tex:SetPoint("CENTER", bagSlotFrame, "CENTER", 0, 0)
    tex:SetWidth(bagSlotFrame:GetWidth() + 12)
    tex:SetHeight(bagSlotFrame:GetHeight() + 12)
    ov.tex = tex
    ov:Hide()
    overlayFrames[key] = ov
    return ov
end

local function UpdateBagHighlights()
    if not QuiverKeeperConfig.petEnabled then
        for _,ov in pairs(overlayFrames) do ov:Hide() end
        return
    end
    RebuildFoodCache()
    for bag=0,4 do
        for slot=1,GetContainerNumSlots(bag) do
            local key = bag.."_"..slot
            local lnk = GetContainerItemLink(bag,slot)
            local show = false
            if lnk then
                local n = GetItemInfo(lnk)
                if n and petFoodCache[n] then show = true end
            end
            -- Get the actual bag button frame
            local btnName = "ContainerFrame"..(bag+1).."Item"..slot
            local btn = _G[btnName]
            if btn then
                local ov = GetOrCreateOverlay(btn, key)
                if show then ov:Show() else ov:Hide() end
            end
        end
    end
end

-- Tooltip hook: add pet food line (hooksecurefunc = safe, won't break other addons)
hooksecurefunc(GameTooltip, "SetBagItem", function(self, bag, slot)
    if not QuiverKeeperConfig.petEnabled then return end
    local lnk = GetContainerItemLink(bag, slot)
    if not lnk then return end
    local n = GetItemInfo(lnk)
    if n and petFoodCache[n] then
        local family = petFoodCacheFamily or "your pet"
        self:AddLine(" ")
        self:AddLine("|cff44ff88[QuiverKeeper]|r |cffffffffYour "..family.." eats this!|r")
        self:AddLine("|cffaaaaaa(Keep it — don't vendor!)|r", 0.7, 0.7, 0.7)
        self:Show()
    end
end)


opt = CreateFrame("Frame", "QKOptionsFrame", UIParent, "BasicFrameTemplate")
opt:SetWidth(340); opt:SetHeight(580)
opt:SetFrameStrata("HIGH")
opt:SetPoint("CENTER", UIParent, "CENTER", 0, 30)
opt:EnableMouse(true); opt:SetMovable(true)
opt:RegisterForDrag("LeftButton")
opt:SetScript("OnDragStart", function(self) self:StartMoving() end)
opt:SetScript("OnDragStop",  function(self) self:StopMovingOrSizing() end)
opt:SetClampedToScreen(true); opt:Hide()
opt.TitleText:SetText("|cff00ccffQuiver|rKeeper  |cffaaaaaa"..VERSION.." // "..CODENAME.."|r")

opt:SetBackdrop({
    bgFile   = "Interface\\DialogFrame\\UI-DialogBox-Background",
    edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
    tile=true, tileSize=32, edgeSize=32,
    insets={left=11,right=12,top=12,bottom=11},
})
opt:SetBackdropColor(0.05,0.05,0.08,0.97)
opt:SetBackdropBorderColor(0.4,0.78,1,0.8)

-- ── panel helpers ────────────────────────────
local function FSL(p,txt,x,y,sz,r,g,b)
    local f=p:CreateFontString(nil,"OVERLAY")
    f:SetPoint("TOPLEFT",p,"TOPLEFT",x,y)
    f:SetFont("Fonts\\FRIZQT__.TTF",sz or 11,"OUTLINE")
    f:SetTextColor(r or 0.88,g or 0.88,b or 0.88,1)
    f:SetText(txt); return f
end

local function SecBar(p,txt,y,r,g,b)
    r,g,b=r or 0.4,g or 0.78,b or 1
    FSL(p,txt,14,y,12,r,g,b)
    local ln=p:CreateTexture(nil,"ARTWORK"); ln:SetHeight(1)
    ln:SetPoint("TOPLEFT",p,"TOPLEFT",14,y-15)
    ln:SetPoint("TOPRIGHT",p,"TOPRIGHT",-14,y-15)
    ln:SetTexture(r,g,b,0.22)
end

local function MakeCB(p,lbl,x,y,cfgKey,onChange)
    local cb=CreateFrame("CheckButton",nil,p,"UICheckButtonTemplate")
    cb:SetPoint("TOPLEFT",p,"TOPLEFT",x,y); cb:SetWidth(20); cb:SetHeight(20)
    local t=cb:CreateFontString(nil,"OVERLAY")
    t:SetPoint("LEFT",cb,"RIGHT",4,0)
    t:SetFont("Fonts\\FRIZQT__.TTF",11,"OUTLINE")
    t:SetTextColor(0.88,0.88,0.88,1); t:SetText(lbl)
    cb.cfgKey=cfgKey; cb:SetChecked(QuiverKeeperConfig[cfgKey])
    cb:SetScript("OnClick",function(self)
        QuiverKeeperConfig[self.cfgKey]=self:GetChecked() and true or false
        if onChange then onChange() end
        UpdateAmmoHUD(); UpdatePetHUD()
    end)
    return cb
end

-- ── EditBox with robust save (Enter + FocusLost) ──
local function MakeEB(p,x,y,w,cfgKey)
    -- Dark background so the field is visible over our custom backdrop
    local bg = p:CreateTexture(nil,"BACKGROUND")
    bg:SetPoint("TOPLEFT",     p,"TOPLEFT", x-3,   y+3)
    bg:SetPoint("BOTTOMRIGHT", p,"TOPLEFT", x+w+3, y-17)
    bg:SetTexture(0, 0, 0, 0.55)

    local eb=CreateFrame("EditBox",nil,p,"InputBoxTemplate")
    eb:SetPoint("TOPLEFT",p,"TOPLEFT",x,y)
    eb:SetWidth(w); eb:SetHeight(20)
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(6)
    -- NOT SetNumeric(true) — it swallows OnEnterPressed in 3.3.5
    eb:SetText(tostring(QuiverKeeperConfig[cfgKey]))
    eb.cfgKey=cfgKey

    local function SaveEB(self)
        local v=tonumber(self:GetText())
        if v and v >= 0 then
            QuiverKeeperConfig[self.cfgKey]=math.floor(v)
            self:SetText(tostring(math.floor(v)))
        else
            -- revert to saved value if invalid
            self:SetText(tostring(QuiverKeeperConfig[self.cfgKey]))
        end
        UpdateAmmoHUD(); UpdatePetHUD()
    end

    eb:SetScript("OnEnterPressed", function(self) SaveEB(self); self:ClearFocus() end)
    eb:SetScript("OnEscapePressed", function(self)
        self:SetText(tostring(QuiverKeeperConfig[self.cfgKey])); self:ClearFocus()
    end)
    eb:SetScript("OnEditFocusLost", function(self) SaveEB(self) end)
    return eb
end

local function MakeBtn(p,txt,x,y,w,fn)
    local b=CreateFrame("Button",nil,p,"UIPanelButtonTemplate")
    b:SetPoint("TOPLEFT",p,"TOPLEFT",x,y); b:SetWidth(w); b:SetHeight(22); b:SetText(txt)
    b:SetScript("OnClick",fn); return b
end

-- ── Scale slider ─────────────────────────────
SecBar(opt,"Display size  (drag corner grip to resize)",-30)
FSL(opt,"Scale",20,-50,11)
local scSl=CreateFrame("Slider",nil,opt,"OptionsSliderTemplate")
scSl:SetPoint("TOPLEFT",opt,"TOPLEFT",20,-65)
scSl:SetWidth(255); scSl:SetMinMaxValues(5,30); scSl:SetValueStep(1)
scSl:SetValue(math.floor(QuiverKeeperConfig.scale*10+0.5))
scSl.Low:SetText("0.5x"); scSl.High:SetText("3.0x")
scSl.Text:SetText(string.format("%.1fx",QuiverKeeperConfig.scale))
scSl:SetScript("OnValueChanged",function(self,val)
    val=math.floor(val+0.5)
    QuiverKeeperConfig.scale=val/10
    self.Text:SetText(string.format("%.1fx",val/10))
    ApplyScale()
end)

-- ── Ammo section ─────────────────────────────
SecBar(opt,"Ammo settings",-105,0.4,0.78,1)
FSL(opt,"|cffFFD700Yellow|r warn at:",20,-126,11)
local ammoYEB=MakeEB(opt,170,-122,60,"warnYellow")
FSL(opt,"|cffFF5555Red|r warn at:",20,-149,11)
local ammoREB=MakeEB(opt,170,-145,60,"warnRed")
FSL(opt,"Tab or click away to apply",20,-168,9,0.45,0.45,0.45)

local cbAmmoLabel=MakeCB(opt,"Show ammo type label",     20,-185,"showLabel")
local cbFlash    =MakeCB(opt,"Flash animation at zero",  20,-207,"flashZero")
local cbChat     =MakeCB(opt,"Zone-in chat warning",     20,-229,"chatWarning")

-- ── Pet food section ─────────────────────────
SecBar(opt,"Pet food settings",-255,0.4,1,0.6)
local cbPet=MakeCB(opt,"Enable pet food HUD",20,-276,"petEnabled",function()
    if QuiverKeeperConfig.petEnabled then petHUD:Show() else petHUD:Hide() end
end)
-- Snap status (read-only, updates on open)
FSL(opt,"|cffaaaaaa  Drag pet HUD near ammo to snap · drag away to free|r",20,-300,9,0.5,0.5,0.5)
local snapStatusLabel = FSL(opt,"",20,-314,10)  -- filled on OnShow
FSL(opt,"|cffFFD700Yellow|r warn at:",20,-333,11)
local petYEB=MakeEB(opt,170,-329,60,"petWarnYellow")
FSL(opt,"|cffFF5555Red|r warn at:",20,-356,11)
local petREB=MakeEB(opt,170,-352,60,"petWarnRed")
FSL(opt,"Counts all food your pet eats across all bags",20,-375,9,0.45,0.45,0.45)

-- ── Position section ─────────────────────────
SecBar(opt,"Position",-382)
MakeBtn(opt,"Reset ammo HUD",20,-402,130,function()
    QuiverKeeperConfig.posX=nil; QuiverKeeperConfig.posY=nil
    ammoHUD:ClearAllPoints()
    ammoHUD:SetPoint("BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",-220,120)
    ApplyMagnetic(); MSG(PREFIX.." Ammo HUD reset.")
end)
MakeBtn(opt,"Reset pet HUD",158,-402,120,function()
    QuiverKeeperConfig.petPosX=nil; QuiverKeeperConfig.petPosY=nil
    QuiverKeeperConfig.petMagnetic=false
    petHUD:ClearAllPoints()
    petHUD:SetPoint("BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",-220,20)
    MSG(PREFIX.." Pet HUD reset.")
end)

local cbLock=MakeCB(opt,"Lock both HUDs",20,-432,"locked")
MakeBtn(opt,"Vendors",170,-429,80,function() opt:Hide(); PrintVendors() end)
MakeBtn(opt,"Close",  258,-429,68,function() opt:Hide() end)

-- ── PenFifteen Club credit block (DeathMark style) ───────────────
local divider = opt:CreateTexture(nil,"ARTWORK")
divider:SetHeight(1)
divider:SetPoint("TOPLEFT",  opt,"TOPLEFT",  14, -460)
divider:SetPoint("TOPRIGHT", opt,"TOPRIGHT", -14, -460)
divider:SetTexture(0.4, 0.78, 1, 0.15)

FSL(opt, "|cff00ccffQuiverKeeper|r  |cffffffff"..VERSION.."|r  |cffaaaaaa// "..CODENAME.."|r",
    14, -474, 11)
FSL(opt, "|cffaaaaaa\"The PenFifteen Club\"  —  Longshaft's Emporium|r",
    14, -491, 10, 0.6, 0.6, 0.6)
FSL(opt, "|cffaaaaaa/qk  ·  /qk debug  ·  /qk vendors|r",
    14, -507, 9, 0.45, 0.45, 0.45)
FSL(opt, "|cffaaaaaaRight-click either HUD to open this panel|r",
    14, -521, 9, 0.45, 0.45, 0.45)

-- refresh on open
opt:SetScript("OnShow",function()
    cbAmmoLabel:SetChecked(QuiverKeeperConfig.showLabel)
    cbFlash:SetChecked(QuiverKeeperConfig.flashZero)
    cbChat:SetChecked(QuiverKeeperConfig.chatWarning)
    cbPet:SetChecked(QuiverKeeperConfig.petEnabled)
    cbLock:SetChecked(QuiverKeeperConfig.locked)
    scSl:SetValue(math.floor(QuiverKeeperConfig.scale*10+0.5))
    ammoYEB:SetText(tostring(QuiverKeeperConfig.warnYellow))
    ammoREB:SetText(tostring(QuiverKeeperConfig.warnRed))
    petYEB:SetText(tostring(QuiverKeeperConfig.petWarnYellow))
    petREB:SetText(tostring(QuiverKeeperConfig.petWarnRed))
    -- Snap status
    if QuiverKeeperConfig.petMagnetic then
        local side = QuiverKeeperConfig.petMagSide or "BOTTOM"
        snapStatusLabel:SetText("|cff44ff88  Snapped: "..side.." side|r")
    else
        snapStatusLabel:SetText("|cffaaaaaa  Free (not snapped)|r")
    end
end)

-- ─────────────────────────────────────────────
--  HUD hover tooltips
-- ─────────────────────────────────────────────
local function HUDTip(self, title)
    if not QuiverKeeperConfig.locked then
        GameTooltip:SetOwner(self,"ANCHOR_TOP")
        GameTooltip:SetText("|cff00ccff"..title.."|r",1,1,1)
        GameTooltip:AddLine("Left-drag to move",0.8,0.8,0.8)
        GameTooltip:AddLine("Right-click for options",0.8,0.8,0.8)
        GameTooltip:Show()
    end
end
ammoHUD:SetScript("OnEnter", function(s) HUDTip(s,"QuiverKeeper — Ammo") end)
ammoHUD:SetScript("OnLeave", function() GameTooltip:Hide() end)
petHUD:SetScript("OnEnter",  function(s) HUDTip(s,"QuiverKeeper — Pet Food") end)
petHUD:SetScript("OnLeave",  function() GameTooltip:Hide() end)

-- ─────────────────────────────────────────────
--  Slash commands  /qk  and  /quiverkeeper
-- ─────────────────────────────────────────────
SLASH_QUIVERKEEPER1 = "/qk"
SLASH_QUIVERKEEPER2 = "/quiverkeeper"
SlashCmdList["QUIVERKEEPER"] = function(msg)
    local cmd=(msg:match("^(%S+)") or ""):lower()
    if cmd=="" or cmd=="options" or cmd=="opt" then
        if opt:IsShown() then opt:Hide() else opt:Show() end
    elseif cmd=="vendors" then
        PrintVendors()
    elseif cmd=="debug" then
        RunDebug()
    elseif cmd=="lock" then
        QuiverKeeperConfig.locked=not QuiverKeeperConfig.locked
        MSG(PREFIX.." "..(QuiverKeeperConfig.locked and "|cffff4444Locked|r" or "|cff44ff44Unlocked|r"))
        UpdateAmmoHUD(); UpdatePetHUD()
    elseif cmd=="snap" then
        QuiverKeeperConfig.petMagnetic=not QuiverKeeperConfig.petMagnetic
        ApplyMagnetic()
        MSG(PREFIX.." Magnetic snap "..(QuiverKeeperConfig.petMagnetic and "|cff44ff44on|r" or "|cffff4444off|r"))
    elseif cmd=="pet" then
        QuiverKeeperConfig.petEnabled=not QuiverKeeperConfig.petEnabled
        if QuiverKeeperConfig.petEnabled then petHUD:Show() else petHUD:Hide() end
        MSG(PREFIX.." Pet HUD "..(QuiverKeeperConfig.petEnabled and "|cff44ff44enabled|r" or "|cffff4444disabled|r"))
    elseif cmd=="reset" then
        QuiverKeeperConfig.posX=nil; QuiverKeeperConfig.posY=nil
        ammoHUD:ClearAllPoints()
        ammoHUD:SetPoint("BOTTOMRIGHT",UIParent,"BOTTOMRIGHT",-220,120)
        ApplyMagnetic(); MSG(PREFIX.." Ammo HUD position reset.")
    else
        MSG(PREFIX.." |cffaaaaaav"..VERSION.."|r  commands:")
        MSG("  /qk               — options panel")
        MSG("  /qk vendors       — ammo + pet food vendor list")
        MSG("  /qk debug         — bag scan diagnostic")
        MSG("  /qk snap          — toggle magnetic pet HUD")
        MSG("  /qk pet           — toggle pet food HUD")
        MSG("  /qk lock          — toggle HUD lock")
        MSG("  /qk reset         — reset ammo HUD position")
    end
end

-- ─────────────────────────────────────────────
--  Events
-- ─────────────────────────────────────────────
local ev=CreateFrame("Frame")
ev:RegisterEvent("PLAYER_LOGIN")
ev:RegisterEvent("BAG_UPDATE")
ev:RegisterEvent("UNIT_INVENTORY_CHANGED")
ev:RegisterEvent("PLAYER_ENTERING_WORLD")
ev:RegisterEvent("UNIT_PET")
ev:RegisterEvent("BAG_UPDATE_DELAYED")

ev:SetScript("OnEvent",function(self,event)
    if event=="PLAYER_LOGIN" then
        local delay=CreateFrame("Frame"); local t=0
        delay:SetScript("OnUpdate",function(d,dt)
            t=t+dt
            if t>=1.5 then
                delay:SetScript("OnUpdate",nil)
                -- Fill any missing keys (handles upgrades from old saved configs)
                local defaults = {
                    warnYellow=200, warnRed=100, scale=1.0,
                    locked=false, showLabel=true, flashZero=true, chatWarning=true,
                    petEnabled=true, petWarnYellow=5, petWarnRed=2,
                    petMagnetic=true, petMagSide="BOTTOM",
                }
                for k,v in pairs(defaults) do
                    if QuiverKeeperConfig[k] == nil then
                        QuiverKeeperConfig[k] = v
                    end
                end
                RestorePositions(); ApplyScale()
                UpdateAmmoHUD(); UpdatePetHUD(); UpdateBagHighlights()
                -- Branded header exactly like DeathMark style
                MSG("|cff00ccff--------------------------------------|r")
                MSG("|cff00ccff  QuiverKeeper|r  "..
                    "|cffffffff"..VERSION.."|r"..
                    "  |cffaaaaaa// "..CODENAME.."|r")
                MSG("|cffaaaaaa  The PetNess Club™  —  Longshaft's Emporium|r")
                MSG("|cffaaaaaa  Right-click HUD  or  |cffffffff/qk|r")
                MSG("|cff00ccff--------------------------------------|r")
            end
        end)
    elseif event=="PLAYER_ENTERING_WORLD" then
        UpdateAmmoHUD(); UpdatePetHUD()
        if QuiverKeeperConfig.chatWarning then
            local ac=GetAmmoInfo()
            if ac<=QuiverKeeperConfig.warnRed then
                MSG(PREFIX.." |cffFF4444Low ammo!|r Only "..ac.." shots remaining.")
            end
            local pc,pf=GetPetFoodInfo()
            if pf and pc<=QuiverKeeperConfig.petWarnRed then
                MSG(PREFIX.." |cffFF4444Low pet food!|r Only "..pc.." items for your "..pf..".")
            end
        end
    elseif event=="BAG_UPDATE" or event=="UNIT_INVENTORY_CHANGED" or event=="BAG_UPDATE_DELAYED" then
        UpdateAmmoHUD(); UpdatePetHUD(); UpdateBagHighlights()
    elseif event=="UNIT_PET" then
        petFoodCacheFamily = nil  -- force cache rebuild on pet change
        UpdatePetHUD(); UpdateBagHighlights()
    end
end)
